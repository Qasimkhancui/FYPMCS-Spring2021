package com.example.smarttailoringservices;

import android.os.Bundle;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class ShowingTailors extends AppCompatActivity
{
   RecyclerView recview;
   tailoradapter adapter;
    private SearchView searchView;
    FirebaseRecyclerOptions<Tailor_Pro_Help> options;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_showing_tailors);

        searchView = (SearchView) findViewById(R.id.searchView);


        recview=(RecyclerView)findViewById(R.id.recview2);
        recview.setLayoutManager(new LinearLayoutManager(this));
      //  FirebaseDatabase.getInstance().setPersistenceEnabled(true);


         options =
                new FirebaseRecyclerOptions.Builder<Tailor_Pro_Help>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("Record").child("Tailor"), Tailor_Pro_Help.class)
                        .build();


        adapter=new tailoradapter(options);
        recview.setAdapter(adapter);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }
            @Override
            public boolean onQueryTextChange(String newText) {

                refreshList(newText);


                return true;
            }
        });



    }

    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }

    public void refreshList(String search){
        String pquery = search.toLowerCase();
        Query sQuery = FirebaseDatabase.getInstance().getReference().child("Record").child("Tailor").orderByChild("tailor_name").startAt(pquery).endAt(pquery+ "\uf8ff");

        options =
                new FirebaseRecyclerOptions.Builder<Tailor_Pro_Help>()
                        .setQuery(/*FirebaseDatabase.getInstance().getReference().child("ConsumerProfiles")*/sQuery, Tailor_Pro_Help.class)
                        .build();


        adapter=new tailoradapter(options);
        recview.setAdapter(adapter);
        adapter.startListening();
    }

}