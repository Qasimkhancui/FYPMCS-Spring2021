package com.example.smarttailoringservices;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class ShowingTailorsforUsersUniform extends AppCompatActivity
{
   RecyclerView recview;
   tailoruseruniformadapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_showing_tailors_users_unifrom);

        recview=(RecyclerView)findViewById(R.id.recview18);
        recview.setLayoutManager(new LinearLayoutManager(this));
        //FirebaseDatabase.getInstance().setPersistenceEnabled(true);
        SharedPreferences prefs = getSharedPreferences(
                "userName", Context.MODE_PRIVATE);
        String userNameKey = "usName";
        String userName1=prefs.getString(userNameKey,"");



        FirebaseRecyclerOptions<String> options =
                new FirebaseRecyclerOptions.Builder<String>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("HierarchyPendingOrdersForUserUniform").child(userName1), String.class)
                        .build();


        adapter=new tailoruseruniformadapter(options);
        recview.setAdapter(adapter);


    }

    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}