package com.example.smarttailoringservices;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class ShowingUsersforTailorUniform extends AppCompatActivity
{
   RecyclerView recview;
   viewinguserontailoruniformadapter adapter;
    private SearchView searchView;
    FirebaseRecyclerOptions<String> options;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_showing_users_tailor_uniform);
        Intent intent=getIntent();
        String clientName=intent.getStringExtra("artname");
        searchView = (SearchView) findViewById(R.id.searchView12);


        recview=(RecyclerView)findViewById(R.id.recview12);
        recview.setLayoutManager(new LinearLayoutManager(this));
        //FirebaseDatabase.getInstance().setPersistenceEnabled(true);
        SharedPreferences prefs = getSharedPreferences(
                "userName", Context.MODE_PRIVATE);
        String userNameKey = "usName";
        String userName1=prefs.getString(userNameKey,"");


         options =
                new FirebaseRecyclerOptions.Builder<String>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("HierarchyPendingOrdersForTailorUniform").child(userName1), String.class)
                        .build();


        adapter=new viewinguserontailoruniformadapter(options);
        recview.setAdapter(adapter);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }
            @Override
            public boolean onQueryTextChange(String newText) {

                refreshList(newText);


                return true;
            }
        });



    }

    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }


    public void refreshList(String search){

    }

}