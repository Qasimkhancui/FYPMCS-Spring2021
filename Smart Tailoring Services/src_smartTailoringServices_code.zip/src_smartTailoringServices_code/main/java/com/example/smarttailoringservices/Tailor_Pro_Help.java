package com.example.smarttailoringservices;

import java.io.Serializable;

public class Tailor_Pro_Help implements Serializable {
    String tailor_name;
    String phone_no;
    String specialization;
    String experience;
    String daily_order;
    String shope_location;
    String temail;
    String imgPath;
    public Tailor_Pro_Help() {
    }

    public Tailor_Pro_Help(String tailor_name, String phone_no, String specialization, String experience, String daily_order, String shope_location, String temail,String imgPath) {
        this.tailor_name = tailor_name;
        this.phone_no = phone_no;
        this.specialization = specialization;
        this.experience = experience;
        this.daily_order = daily_order;
        this.shope_location = shope_location;
        this.temail = temail;
        this.imgPath=imgPath;
    }

    public String getImgPath() {
        return imgPath;
    }

    public void setImgPath(String imgPath) {
        this.imgPath = imgPath;
    }

    public String getTailor_name() {
        return tailor_name;
    }

    public void setTailor_name(String tailor_name) {
        this.tailor_name = tailor_name;
    }

    public String getPhone_no() {
        return phone_no;
    }

    public void setPhone_no(String phone_no) {
        this.phone_no = phone_no;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public String getExperience() {
        return experience;
    }

    public void setExperience(String experience) {
        this.experience = experience;
    }

    public String getDaily_order() {
        return daily_order;
    }

    public void setDaily_order(String daily_order) {
        this.daily_order = daily_order;
    }

    public String getShope_location() {
        return shope_location;
    }

    public void setShope_location(String shope_location) {
        this.shope_location = shope_location;
    }

    public String getTemail() {
        return temail;
    }

    public void setTemail(String temail) {
        this.temail = temail;
    }
}
