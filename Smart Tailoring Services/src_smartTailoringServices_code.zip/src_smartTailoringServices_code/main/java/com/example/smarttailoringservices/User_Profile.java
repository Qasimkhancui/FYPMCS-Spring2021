package com.example.smarttailoringservices;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class User_Profile extends AppCompatActivity {
    private TextView uname, email, address,phone;
    private DatabaseReference dataRef;
    private FirebaseAuth firebaseAuth;
    private ImageView uImage;
    public Uri imgUri;
    private FirebaseStorage mStorage;
    private StorageReference mStroageReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user__profile);
        Initial();
        firebaseAuth = FirebaseAuth.getInstance();
        dataRef = FirebaseDatabase.getInstance().getReference();
        mStorage = FirebaseStorage.getInstance();
        mStroageReference = mStorage.getReference();
        getData();
        String userId=firebaseAuth.getCurrentUser().getUid();

        uImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              //  ChoosePic();
            }
        });


    }

    private void ChoosePic() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Pick image"), 1000);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == 1000 && resultCode == RESULT_OK && data != null) {
            imgUri = data.getData();
            uImage.setImageURI(imgUri);
        }


        super.onActivityResult(requestCode, resultCode, data);

    }


    public void Initial(){
        uname=findViewById(R.id.u_name);
        email=findViewById(R.id.u_email);
        phone=findViewById(R.id.u_phone);
        address=findViewById(R.id.u_address);
        uImage=findViewById(R.id.U_pic);
    }
    public void getData(){
        String ref = firebaseAuth.getCurrentUser().getUid();
        dataRef.child("User").child(ref).child("Username").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String userName=snapshot.getValue(String.class);
                Toast.makeText(User_Profile.this, userName, Toast.LENGTH_SHORT).show();
                dataRef.child("Record").child("Client").child(userName).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        Profile uprofile=snapshot.getValue(Profile.class);
                        uname.setText("Username: "+uprofile.getUname());
                        email.setText("Email: "+uprofile.getEmail());
                        phone.setText("Phone: "+uprofile.getPhone());
                        address.setText("Address: "+uprofile.getAddress());

                        String en=uprofile.getImgpath();
                        byte[] decodedString = Base64.decode(en, Base64.DEFAULT);
                        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                        uImage.setImageBitmap(decodedByte);

                       // specialization.setText("Specialization: "+tprofile.getSpecialization());
                      //  daily_order.setText("Daily Orders: "+tprofile.getDaily_order());
                     //   shope_location.setText("Shope Location: "+tprofile.getShope_location());
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                }) ;

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }
}