package com.example.smarttailoringservices;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

import java.io.Serializable;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import de.hdodenhof.circleimageview.CircleImageView;

public class confirmordersadapter extends FirebaseRecyclerAdapter<OrderClass, confirmordersadapter.myviewholder>
{    FirebaseRecyclerOptions<OrderClass> options;
    public confirmordersadapter(@NonNull FirebaseRecyclerOptions<OrderClass> options) {
        super(options);
        this.options=options;
    }

    @Override
    protected void onBindViewHolder(@NonNull myviewholder holder, final int position, @NonNull final OrderClass artist)
    {
       // String en=artist.getImgpath();
       // byte[] decodedString = Base64.decode(en, Base64.DEFAULT);
      //  Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);


        holder.name.setText(artist.getOrdernumber());
       //holder.course.setText("");
       //holder.email.setText("");
       holder.btnAccept.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               Toast.makeText(view.getContext(), "Order Id"+artist.getOrdernumber(), Toast.LENGTH_SHORT).show();
           }
       });
      // Glide.with(holder.img.getContext()).load(decodedByte).into(holder.img);


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), CompletingUpdatingDetailsActivity.class);
                intent.putExtra("model", (Serializable) artist);
                //intent.putExtra("artname", artist.getArtistName());

                v.getContext().startActivity(intent);
            }
        });






    }

    @NonNull
    @Override
    public myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
       View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.singlerow2,parent,false);

       return new myviewholder(view);
    }



    class myviewholder extends RecyclerView.ViewHolder
    {
        CircleImageView img;
        TextView name,course,email;
        Button btnAccept,btnReject;
        public myviewholder(@NonNull View itemView)
        {
            super(itemView);
            name=(TextView)itemView.findViewById(R.id.nametext2);

            btnAccept=itemView.findViewById(R.id.btnAccept);
            btnReject=itemView.findViewById(R.id.btnReject);







        }
    }
}
