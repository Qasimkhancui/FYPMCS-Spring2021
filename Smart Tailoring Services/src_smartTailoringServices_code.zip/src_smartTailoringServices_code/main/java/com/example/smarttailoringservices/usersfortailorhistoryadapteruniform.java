package com.example.smarttailoringservices;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import de.hdodenhof.circleimageview.CircleImageView;

public class usersfortailorhistoryadapteruniform extends FirebaseRecyclerAdapter<String, usersfortailorhistoryadapteruniform.myviewholder>
{    FirebaseRecyclerOptions<String> options;
    public usersfortailorhistoryadapteruniform(@NonNull FirebaseRecyclerOptions<String> options) {
        super(options);
        this.options=options;
    }

    @Override
    protected void onBindViewHolder(@NonNull myviewholder holder, final int position, @NonNull final String artist)
    {
       // String en=artist.getImgpath();
       // byte[] decodedString = Base64.decode(en, Base64.DEFAULT);
      //  Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);


        holder.name.setText(artist.toString());
       holder.course.setText("");
       holder.email.setText("");
      // Glide.with(holder.img.getContext()).load(decodedByte).into(holder.img);


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), ShowingHistoryUniformTailor.class);
               // intent.putExtra("model", artist);
                intent.putExtra("histname", artist.toString());

                v.getContext().startActivity(intent);

            }
        });






    }

    @NonNull
    @Override
    public myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
       View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.singlerow,parent,false);

       return new myviewholder(view);
    }



    class myviewholder extends RecyclerView.ViewHolder
    {
        CircleImageView img;
        TextView name,course,email;
        public myviewholder(@NonNull View itemView)
        {
            super(itemView);
            img=(CircleImageView)itemView.findViewById(R.id.img1);
            name=(TextView)itemView.findViewById(R.id.nametext);
            course=(TextView)itemView.findViewById(R.id.coursetext);
            email=(TextView)itemView.findViewById(R.id.emailtext);






        }
    }
}
