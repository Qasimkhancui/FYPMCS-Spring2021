package com.example.smarttailoringservices;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class EditingConfirmOrdersTailorSide extends AppCompatActivity
{
   RecyclerView recview;
   confirmorderseditadapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editing_confirm_orders);
        Intent intent=getIntent();
        String tailName=intent.getStringExtra("conartname");
        SharedPreferences prefs = getSharedPreferences(
                "userName", Context.MODE_PRIVATE);
        String userNameKey = "usName";
        String userName1=prefs.getString(userNameKey,"");

        recview=(RecyclerView)findViewById(R.id.recview21);
        recview.setLayoutManager(new LinearLayoutManager(this));
        //FirebaseDatabase.getInstance().setPersistenceEnabled(true);


        FirebaseRecyclerOptions<OrderClass> options =
                new FirebaseRecyclerOptions.Builder<OrderClass>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("ConfirmOrdersForTailor").child(userName1).child(tailName), OrderClass.class)
                        .build();


        adapter=new confirmorderseditadapter(options);
        recview.setAdapter(adapter);


    }

    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}