package com.example.smarttailoringservices;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class Selection_Screen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selection__screen);
    }

    public void buttontailor(View view) {
        Intent intent = new Intent(this, Tailor_SignUp.class);
        Toast.makeText(this, "You Select the Option as the Tailor", Toast.LENGTH_SHORT).show();
        startActivity(intent);
    }

    public void btncustomer(View view) {
        Intent intent = new Intent(this, User_SignUp.class);
        Toast.makeText(this, "You Select the Option as a Customer", Toast.LENGTH_SHORT).show();
        startActivity(intent);
    }
}