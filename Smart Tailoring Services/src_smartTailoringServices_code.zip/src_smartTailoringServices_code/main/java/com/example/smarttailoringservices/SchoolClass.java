package com.example.smarttailoringservices;

import java.io.Serializable;

public class SchoolClass implements Serializable {

    private String schoolName,orderQuantity,orderGents,uniformImg;
    String ordernumber;


    public SchoolClass(){}

    public void setUniformImg(String uniformImg) {
        this.uniformImg = uniformImg;
    }

    public String getUniformImg() {
        return uniformImg;
    }

    public String getOrdernumber() {
        return ordernumber;
    }

    public void setOrdernumber(String ordernumber) {
        this.ordernumber = ordernumber;
    }

    public void setOrderGents(String orderGents) {
        this.orderGents = orderGents;
    }

    public void setOrderQuantity(String orderQuantity) {
        this.orderQuantity = orderQuantity;
    }

    public void setSchoolName(String schoolName) {
        this.schoolName = schoolName;
    }

    public String getOrderGents() {
        return orderGents;
    }

    public String getSchoolName() {
        return schoolName;
    }

    public String getOrderQuantity() {
        return orderQuantity;
    }
}
