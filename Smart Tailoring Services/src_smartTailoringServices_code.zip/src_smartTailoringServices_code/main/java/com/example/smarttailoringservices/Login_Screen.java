package com.example.smarttailoringservices;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Login_Screen extends AppCompatActivity {
    private EditText Email, Password;
    private Button btnlogin,sign,btnUserManual;
    public static final int REQUEST_ID_MULTIPLE_PERMISSIONS = 1;


    private FirebaseAuth firebaseAuth;
    FirebaseDatabase Database;
    DatabaseReference dataRef;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login__screen);


        firebaseAuth = FirebaseAuth.getInstance();
        Database = FirebaseDatabase.getInstance();
        dataRef = Database.getReference("User");
        checkAndRequestPermissions();

        Initial();

        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String eemail = Email.getText().toString().trim();
                final String ppassword = Password.getText().toString().trim();
                if(eemail.isEmpty()){
                    Email.setError("Enter Email");
                    Email.requestFocus();
                    return;
                }
                if(ppassword.isEmpty()){
                    Password.setError("Enter Password");
                    Password.requestFocus();
                    return;
                }
                firebaseAuth.signInWithEmailAndPassword(eemail, ppassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            String vol = firebaseAuth.getCurrentUser().getUid();

                            dataRef.child(vol).child("Username").addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    String s = dataSnapshot.getValue(String.class);
                                    SharedPreferences prefs = getSharedPreferences(
                                            "userName", Context.MODE_PRIVATE);
                                    prefs.edit().putString("usName",s).apply();

                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {
                                }
                            });


                            dataRef.child(vol).child("Role").addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    String s = dataSnapshot.getValue(String.class);
                                    if (s.equalsIgnoreCase("Tailor")) {
                                        Intent it = new Intent(Login_Screen.this, Tailor_Dashboard.class);
                                        startActivity(it);
                                    } else if (s.equalsIgnoreCase("Client")) {
                                        Intent it = new Intent(Login_Screen.this, User_Dashboard.class);
                                        startActivity(it);
                                    } else {
                                        Toast.makeText(Login_Screen.this, "User is Not available", Toast.LENGTH_SHORT).show();
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {
                                }
                            });


                        } else {
                            Toast.makeText(Login_Screen.this, "Log in failed", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

            }
        });
    }
    public void btn_sign(View view) {
        Intent intent=new Intent(Login_Screen.this,Selection_Screen.class);
        startActivity(intent);
    }
    public void Initial(){
        Email = (EditText) findViewById(R.id.etemail);
        Password = (EditText) findViewById(R.id.etpasswword);
        btnlogin = (Button) findViewById(R.id.btnlogin);
        sign=(Button)findViewById(R.id.btn_sign);
    }



    private  boolean checkAndRequestPermissions() {
        int camera = ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA);
        int storage = ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
        int loc = ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION);
        int loc2 = ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION);
        List<String> listPermissionsNeeded = new ArrayList<>();

        if (camera != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(android.Manifest.permission.CAMERA);
        }
        if (storage != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (loc2 != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(android.Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if (loc != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(android.Manifest.permission.ACCESS_COARSE_LOCATION);
        }
        if (!listPermissionsNeeded.isEmpty())
        {
            ActivityCompat.requestPermissions(this,listPermissionsNeeded.toArray
                    (new String[listPermissionsNeeded.size()]),REQUEST_ID_MULTIPLE_PERMISSIONS);
            return false;
        }
        return true;
    }


}

