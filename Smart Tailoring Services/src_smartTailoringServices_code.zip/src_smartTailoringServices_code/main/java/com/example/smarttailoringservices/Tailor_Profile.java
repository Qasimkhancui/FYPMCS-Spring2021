package com.example.smarttailoringservices;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Tailor_Profile extends AppCompatActivity {
private TextView tailor_name, phone_no, specialization, experience, daily_order, shope_location,temail, upassword, uconfirmpassword;

    private DatabaseReference dataRef;
    private FirebaseAuth firebaseAuth;
    private ImageView tImage;
    public Uri ImgUri;
    private FirebaseStorage firebaseStorage;
    private StorageReference StgReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tailor__profile);
        Initialization();
        firebaseAuth = FirebaseAuth.getInstance();
        dataRef = FirebaseDatabase.getInstance().getReference();
        firebaseStorage= FirebaseStorage.getInstance();
        StgReference = firebaseStorage.getReference();
        getData();
        String userId=firebaseAuth.getCurrentUser().getUid();
        StorageReference profileRef = StgReference.child("images/userId").child(userId);
        profileRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                Picasso.get().load(uri).into(tImage);

            }
        });
        tImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            //   ChoosePic();
            }
        });


    }

    private void ChoosePic() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Pick image"), 1000);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == 1000 && resultCode == RESULT_OK && data != null) {
            ImgUri = data.getData();
            tImage.setImageURI(ImgUri);
            uploadPic();
        }


        super.onActivityResult(requestCode, resultCode, data);

    }
    public void Initialization(){
        tailor_name=findViewById(R.id.Tailor_name);
        phone_no=findViewById(R.id.Tailor_phone);
        specialization=findViewById(R.id.Tailor_specialization);
        experience=findViewById(R.id.Tilor_Experience);
        daily_order=findViewById(R.id.Tailor_Daily_Order);
        shope_location=findViewById(R.id.Tailor_Shope_Location);
        temail=findViewById(R.id.Tailor_Email);
        tImage=findViewById(R.id.T_pic);
    }
    private void uploadPic() {
        final ProgressDialog pd=new ProgressDialog(this);
        pd.setTitle("Uploading Image...");
        pd.show();
        String userId=firebaseAuth.getCurrentUser().getUid();
        StorageReference riversRef = StgReference.child("images/userId").child(userId);
        riversRef.putFile(ImgUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                pd.dismiss();
                Toast.makeText(Tailor_Profile.this, "image is uploaded", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                pd.dismiss();
                Toast.makeText(Tailor_Profile.this, "Image Uploading is unSuccessful", Toast.LENGTH_SHORT).show();
            }
        }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onProgress(@NonNull UploadTask.TaskSnapshot snapshot) {
                double pro=     (100*snapshot.getBytesTransferred()/snapshot.getTotalByteCount());
                pd.setMessage("Uploading Image "+(int)pro+"%");
            }
        });

    }
    public void getData(){
        String ref = firebaseAuth.getCurrentUser().getUid();
        dataRef.child("User").child(ref).child("Username").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String userName=snapshot.getValue(String.class);
                dataRef.child("Record").child("Tailor").child(userName).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        Tailor_Pro_Help tprofile=snapshot.getValue(Tailor_Pro_Help.class);
                        String en=tprofile.getImgPath();
                        byte[] decodedString = Base64.decode(en, Base64.DEFAULT);
                        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                        tImage.setImageBitmap(decodedByte);
                        tailor_name.setText("Username: "+tprofile.getTailor_name());
                        phone_no.setText("Phone: "+tprofile.getPhone_no());
                        temail.setText("Email: "+tprofile.getTemail());
                        experience.setText("Experience: "+tprofile.getExperience());
                        specialization.setText("Specialization: "+tprofile.getSpecialization());
                        daily_order.setText("Daily Orders: "+tprofile.getDaily_order());
                        shope_location.setText("Shope Location: "+tprofile.getShope_location());
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                }) ;

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
      /*  dataRef.child("Record").child(ref).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Tailor_Pro_Help tprofile=snapshot.getValue(Tailor_Pro_Help.class);
                tailor_name.setText("Username: "+tprofile.getTailor_name());
                phone_no.setText("Phone: "+tprofile.getPhone_no());
                temail.setText("Email: "+tprofile.getTemail());
                experience.setText("Experience: "+tprofile.getExperience());
                specialization.setText("Specialization: "+tprofile.getSpecialization());
                daily_order.setText("Daily Orders: "+tprofile.getDaily_order());
                shope_location.setText("Shope Location: "+tprofile.getShope_location());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        }) ;*/
    }



}