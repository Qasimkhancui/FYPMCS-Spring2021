package com.example.smarttailoringservices;

import java.io.Serializable;

public class OrderClass implements Serializable {


    String collarinfo;
    String bicepsinfo;
    String backinfo;
    String butoninfo;
    String chestinfo;
    String sleevesinfo;
    String pocketsinfo;
    String stomachinfo;
    String width;
    String thigh;
    String knee;
    String calf;
    String ankelhem;
    String hips;
    String shirtoutseam;
    String shirtinseam;
    String ordernumber;
    String address,imgpath;
    public OrderClass(){}
    public OrderClass(String collarinfo,String bicepsinfo,String backinfo,String butoninfo,String chestinfo,String sleevesinfo,String pocketsinfo,String stomachinfo,String width,String thigh,String knee,String calf,String ankelhem,String hips,String shirtoutseam,String shirtinseam,String ordernumber,String address,String imgpath){
        this.collarinfo=collarinfo;
        this.bicepsinfo=bicepsinfo;
        this.backinfo=backinfo;
        this.butoninfo=butoninfo;
        this.chestinfo=chestinfo;
        this.sleevesinfo=sleevesinfo;
        this.pocketsinfo=pocketsinfo;
        this.stomachinfo=stomachinfo;
        this.width=width;
        this.thigh=thigh;
        this.knee=knee;
        this.calf=calf;
        this.ankelhem=ankelhem;
        this.hips=hips;
        this.shirtoutseam=shirtoutseam;
        this.shirtinseam=shirtinseam;
        this.ordernumber=ordernumber;
        this.address=address;
        this.imgpath=imgpath;
    }

    public String getImgpath() {
        return imgpath;
    }

    public String getAddress() {
        return address;
    }


    public String getCollarinfo()
    {return collarinfo; }
    public String getBicepsinfo(){return bicepsinfo;}
    public String getBackinfo(){return backinfo;}
    public String getButoninfo(){return butoninfo;}
    public String getChestinfo(){return chestinfo;}
    public String getSleevesinfo(){return sleevesinfo;}
    public String getPocketsinfo(){return pocketsinfo;}
    public String getStomachinfo(){return stomachinfo;}
    public String getWidth(){return width;}
    public String getThigh(){return thigh;}
    public String getKnee(){return knee;}
    public String getCalf(){return calf;}
    public String getAnkelhem(){return ankelhem;}
    public String getHips(){return hips;}
    public String getShirtoutseam(){return shirtoutseam;}
    public String getShirtinseam(){return shirtinseam;}
    public String getOrdernumber(){return ordernumber;}








}
