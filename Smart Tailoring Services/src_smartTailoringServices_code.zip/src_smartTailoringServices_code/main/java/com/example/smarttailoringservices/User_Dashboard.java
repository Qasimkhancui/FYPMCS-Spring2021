package com.example.smarttailoringservices;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class User_Dashboard extends AppCompatActivity {
    private FirebaseAuth firebaseAuth;
    private FirebaseDatabase myData;
    private DatabaseReference mRef;
    private Button btn_manual,btn_order1,btnPendingOrder,btnNotif,btnConfirmedOrders,btnlogout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user__dashboard);
        btn_manual=(Button)findViewById(R.id.bttn_manual);
        btnNotif=findViewById(R.id.buttonNotification2);
        btnConfirmedOrders=findViewById(R.id.buttonShare);
        btnlogout=findViewById(R.id.btnlogout);
        firebaseAuth= FirebaseAuth.getInstance();
        myData= FirebaseDatabase.getInstance();
        mRef=myData.getReference();
        btn_order1=findViewById(R.id.buttonAcceptor12);
        btnPendingOrder=findViewById(R.id.btnPending);
        btnPendingOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(User_Dashboard.this,PendingordersOptionsonClient.class);
                startActivity(intent);
            }
        });
        btnNotif.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(User_Dashboard.this,ShowingNotification.class);
                startActivity(intent);

            }
        });

        btn_manual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder=new AlertDialog.Builder(User_Dashboard.this);
                builder.setTitle("User Manual");
                builder.setMessage("Customers Can use this app in following ways: \n * He/She can easily place simple user orders as well as school and organization orders. \n * He/She can open this application and then open the order option and then search the tailor by name and take the order to their favourite and nearest tailor.\n * When the user give their orders one time to thier specefic tailor the order will be save in pending orders list and when the tailor accept or reject his order the user get the notification that his orders are accept or reject.\n * In case of order acceptance the user get the notfication in the specific notification box and the delivery date and completion date is will be mention in this notification. \n * When the taior update the delevery date of any order the user will get notification the the delivery date has been changed and the new date is this.\n * When the user order complete the user will get notificatoin that your order is completed. \n * Once when the user order is completed the order will be saved in the history box and when the user place the order second time to another tailor the user information will be reuse. ");
                builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                    }
                });

                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        btn_order1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(User_Dashboard.this, ShowingTailors.class);
                startActivity(intent);
            }
        });

        btnConfirmedOrders.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(User_Dashboard.this,HistoryOptionsonUserSide.class);
                startActivity(intent);
            }
        });

    }




    public void btn_Profile(View view) {
        Intent intent=new Intent(User_Dashboard.this, User_Profile.class);
        startActivity(intent);
    }

    public void btnlogout(View view) {
        firebaseAuth.signOut();
        finish();
        Toast.makeText(this, "Logout Successful", Toast.LENGTH_SHORT).show();
    }
}