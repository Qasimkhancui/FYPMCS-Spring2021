package com.example.smarttailoringservices;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class HistoryOptionsonTailorSide extends AppCompatActivity {
    Button btnHistUser,btnHistUniform;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history_optionson_tailor_side);
        btnHistUniform=findViewById(R.id.btnHistUniformTailor);
        btnHistUser=findViewById(R.id.btnHistTailor);

        btnHistUniform.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(HistoryOptionsonTailorSide.this,ShowingUsersforTailorHistoryUniform.class);
                startActivity(intent);
            }
        });

        btnHistUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(HistoryOptionsonTailorSide.this,ShowingUsersforTailorHistory.class);
                startActivity(intent);
            }
        });
    }
}