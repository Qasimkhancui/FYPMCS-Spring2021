package com.example.smarttailoringservices;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class HistoryOptionsonUserSide extends AppCompatActivity {
    Button btnHistUser,btnHistUniform;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history_optionson_user_side);
        btnHistUniform=findViewById(R.id.btnHistUniform);
        btnHistUser=findViewById(R.id.btnHistUser);

        btnHistUniform.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(HistoryOptionsonUserSide.this,ShowingTailorsforUsersHistoryUniform.class);
                startActivity(intent);
            }
        });

        btnHistUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(HistoryOptionsonUserSide.this,ShowingTailorsforUsersHistory.class);
                startActivity(intent);
            }
        });
    }
}