package com.example.smarttailoringservices;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class EditingDetailsActivity extends AppCompatActivity {
    private EditText etAdd,etNewDate,etNumber,etFN,etLN,shoulders,etDateBegin,etDateEnd, Chest,Biceps, Arms, Pockets, Paits, Width, Thigh, Knee, Calf, AnkelHem, Hipes, Outstream1, Instream1;
    private DatabaseReference mDatabase,postRef;
    private Button btnAdd;

    ImageView imageView;
    private String savePath;
    private long dateIssue;
    private long dateExpire;
    Bitmap bmp ;
    ByteArrayOutputStream bos;
    byte[] bt ;
    String encodeString;
    private Uri filePath;
    String inputValue;
    private final int PICK_IMAGE_REQUEST = 71;
    SimpleDateFormat DMY_TIME_SLASH_FORMAT;
    SharedPreferences prefs;
    String userName1,userName2;
    OrderClass nm;
    String appDate;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editing_details);
        btnAdd=findViewById(R.id.btnAdd3);
        imageView=findViewById(R.id.viewim);
        etAdd=findViewById(R.id.etadd);
        EditText etHips=findViewById(R.id.etHips2211);
        EditText etSI=findViewById(R.id.etSomeInfo11);
        EditText etSI2=findViewById(R.id.etSomeInfo211);
        EditText etS3=findViewById(R.id.SI311);

        prefs = getSharedPreferences(
                "confirmeduserName1", Context.MODE_PRIVATE);
        String userNameKey = "confirmedusName1";
        userName1=prefs.getString(userNameKey,"");
        prefs = getSharedPreferences(
                "userName", Context.MODE_PRIVATE);
        String userNameKey1 = "usName";
        userName2=prefs.getString(userNameKey1,"");




        DMY_TIME_SLASH_FORMAT = new SimpleDateFormat("d/M/yyyy", Locale.US);


        etNumber=findViewById(R.id.etColl3);
        etFN=findViewById(R.id.FirstName3);
        etLN=findViewById(R.id.etBack3);
        etDateEnd=findViewById(R.id.etSomeInfo11);
        etDateBegin=findViewById(R.id.etDateBegin3);
        Chest=findViewById(R.id.etPockets3);
        Arms=findViewById(R.id.etArms3);
        shoulders=findViewById(R.id.etDateEnd3);
        Pockets=findViewById(R.id.etChest3);
        Paits=findViewById(R.id.etPaits3);
        Width=findViewById(R.id.etWidth3);
        Biceps=findViewById(R.id.etBic3);

        Thigh=findViewById(R.id.etInseam3);
        Instream1=findViewById(R.id.etOutseam3);
        etNewDate=findViewById(R.id.etUpdate);
        //String newdate=etNewDate.getText().toString();









        Intent intent=getIntent();
        nm= (OrderClass) intent.getSerializableExtra("model");
        etNumber.setText(nm.getCollarinfo());
        etFN.setText(nm.getOrdernumber());
        etLN.setText(nm.getSleevesinfo());
        String beginDate=nm.getBackinfo();
        //String expDate=nm.getBicepsinfo();
        etDateBegin.setText(beginDate);
        //etDateEnd.setText(nm.getButoninfo());
        shoulders.setText(nm.getButoninfo());
        Arms.setText(nm.getStomachinfo());
        Pockets.setText(nm.getPocketsinfo());
        Chest.setText(nm.getChestinfo());
        Biceps.setText(nm.getBicepsinfo());
        Paits.setText(nm.getWidth());
        Width.setText(nm.getThigh());
        Thigh.setText(nm.getKnee());
        Instream1.setText(nm.getCalf());
        etAdd.setText(nm.getAddress());

        etHips.setText(nm.getHips());
        etSI.setText(nm.getAnkelhem());
        etSI2.setText(nm.getShirtoutseam());
        etS3.setText(nm.getShirtinseam());
        String en=nm.getImgpath();
        byte[] decodedString = Base64.decode(en, Base64.DEFAULT);
        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        imageView.setImageBitmap(decodedByte);

        etNewDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Calendar calendar = Calendar.getInstance();
                DatePickerDialog datePickerDialog =
                        new DatePickerDialog(EditingDetailsActivity.this, new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view1, int year, int month, int dayOfMonth) {
                                Calendar calendar1 = Calendar.getInstance();
                                calendar1.set(Calendar.YEAR, year);
                                calendar1.set(Calendar.MONTH, month);
                                calendar1.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                                etNewDate.setText(formatDayMonthYear(calendar1.getTime()));
                                appDate = formatDayMonthYear(calendar1.getTime());


                                dateExpire = calendar1.getTimeInMillis();
                            }
                        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH),
                                calendar.get(Calendar.DAY_OF_MONTH));
                datePickerDialog.show();


            }
        });


        //String en=nm.getImgpath();
        // byte[] decodedString = Base64.decode(en, Base64.DEFAULT);
        // Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        // imageView.setImageBitmap(decodedByte);

        mDatabase = FirebaseDatabase.getInstance().getReference().child("ConfirmOrdersForTailor");

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //  if (validateInput())
                addArtist();
            }
        });



    }

    public static String formatDayMonthYear(Date date) {
        SimpleDateFormat FORMAT_DAY_MONTH_YEAR = new SimpleDateFormat("dd MMM yyyy", Locale.US);

        return FORMAT_DAY_MONTH_YEAR.format(date);
    }





    private void chooseImage() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK
                && data != null && data.getData() != null )
        {
            filePath = data.getData();
            try {
                bmp = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                imageView.setImageBitmap(bmp);
                bos = new ByteArrayOutputStream();
                bmp.compress(Bitmap.CompressFormat.JPEG, 100, bos);
                bt = bos.toByteArray();
                encodeString = Base64.encodeToString(bt, Base64.DEFAULT);
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }
    }

    public SimpleDateFormat getDefaultDateFormat() {
        return DMY_TIME_SLASH_FORMAT;
    }
    public String formatTimestamp(long timestamp) {
        return getDefaultDateFormat().format(new Date(timestamp));
    }



    private void addArtist() {
        /*
        String name = etFN.getText().toString();
        String genre = etLN.getText().toString();
        String id = etNumber.getText().toString();
        inputValue = etNumber.getText().toString().trim();
        Bitmap bitmap = ((BitmapDrawable)imageView.getDrawable()).getBitmap();
        bos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bos);
        bt = bos.toByteArray();
        encodeString = Base64.encodeToString(bt, Base64.DEFAULT);

         */





        postRef = FirebaseDatabase.getInstance().getReference();
        postRef.child("Notification").child(userName1).child("Title").child(etFN.getText().toString()).removeValue();

        postRef.child("Notification").child(userName1).child("Title").child(etFN.getText().toString()).setValue("Your Order number"+etFN.getText().toString()+" has been Changed. New Date "+appDate).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                Toast.makeText(EditingDetailsActivity.this, "Updated", Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(EditingDetailsActivity.this,EditingConfirmOrdersTailorSide.class);
                startActivity(intent);
            }
        });


     /*   String name = etFn.getText().toString();
        String genre = etLn.getText().toString();
        String id = etLicNum.getText().toString();
        Artist artist = new Artist(id, name, genre);

        //Saving the Artist
        mDatabase.child(id).setValue(artist);*/
    }






}