package com.example.smarttailoringservices;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class ShowingUsersforTailorHistoryUniform extends AppCompatActivity
{
   RecyclerView recview;
   usersfortailorhistoryadapteruniform adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_showing_users_tailor_history_uniform);

        recview=(RecyclerView)findViewById(R.id.recview27);
        recview.setLayoutManager(new LinearLayoutManager(this));
        //FirebaseDatabase.getInstance().setPersistenceEnabled(true);

        SharedPreferences prefs = getSharedPreferences(
                "userName", Context.MODE_PRIVATE);
        String userNameKey = "usName";
        String userName1=prefs.getString(userNameKey,"");



        FirebaseRecyclerOptions<String> options =
                new FirebaseRecyclerOptions.Builder<String>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("HierarchyHistoryOrderForTailorUniform").child(userName1), String.class)
                        .build();


        adapter=new usersfortailorhistoryadapteruniform(options);
        recview.setAdapter(adapter);


    }

    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}