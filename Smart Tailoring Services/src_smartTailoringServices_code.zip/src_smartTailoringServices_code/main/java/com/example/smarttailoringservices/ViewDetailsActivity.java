package com.example.smarttailoringservices;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ViewDetailsActivity extends AppCompatActivity {
    private EditText etAddress,etNumber,etFN,etLN,Shoulders,etDateBegin,etDateEnd, Chest,Biceps, Arms,Back, Pockets, Paits, Width, Thigh, Knee, Calf, AnkelHem, Hipes, Outstream1, Instream1;
    private DatabaseReference mDatabase,postRef;

    ImageView imageView;
    private String savePath;
    private long dateIssue;
    private long dateExpire;
    Bitmap bmp ;
    ByteArrayOutputStream bos;
    byte[] bt ;
    String encodeString;
    private Uri filePath;
    String inputValue;
    private final int PICK_IMAGE_REQUEST = 71;
    SimpleDateFormat DMY_TIME_SLASH_FORMAT;
    SharedPreferences prefs;
    String userName1,userName2;
    OrderClass nm;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_details);

        imageView=findViewById(R.id.ivViewim);
        etAddress=findViewById(R.id.Address23);

        EditText etHips=findViewById(R.id.etHips22111);
        EditText etSI=findViewById(R.id.etSomeInfo111);
        EditText etSI2=findViewById(R.id.etSomeInfo2111);
        EditText etS3=findViewById(R.id.SI3111);




         prefs = getSharedPreferences(
                "userName1", Context.MODE_PRIVATE);
        String userNameKey = "usName1";
         userName1=prefs.getString(userNameKey,"");
        prefs = getSharedPreferences(
                "userName", Context.MODE_PRIVATE);
        String userNameKey1 = "usName";
        userName2=prefs.getString(userNameKey1,"");




        DMY_TIME_SLASH_FORMAT = new SimpleDateFormat("d/M/yyyy", Locale.US);


        etNumber=findViewById(R.id.etColl2);
        etFN=findViewById(R.id.FirstName2);
        etLN=findViewById(R.id.etArms2);
        etDateEnd=findViewById(R.id.etSomeInfo111);
        Chest=findViewById(R.id.etChest2);
        etDateBegin=findViewById(R.id.etDateBegin2);
        Arms=findViewById(R.id.etBack2);
        Biceps=findViewById(R.id.etBic2);
        Shoulders=findViewById(R.id.etDateEnd2);
        Pockets=findViewById(R.id.etPockets2);
        Paits=findViewById(R.id.etPaits2);
        Width=findViewById(R.id.etWidth2);
        Thigh=findViewById(R.id.etInseam2);
        Instream1=findViewById(R.id.etOutseam2);









        Intent intent=getIntent();
        nm= (OrderClass) intent.getSerializableExtra("model");
        etNumber.setText(nm.getCollarinfo());
        etFN.setText(nm.getOrdernumber());
        etLN.setText(nm.getStomachinfo());
        String beginDate=nm.getBackinfo();
        //String expDate=nm.getBicepsinfo();
        etDateBegin.setText(beginDate);
        //etDateEnd.setText(nm.getButoninfo());
        Shoulders.setText(nm.getButoninfo());
        Arms.setText(nm.getSleevesinfo());
        Biceps.setText(nm.getBicepsinfo());
        Pockets.setText(nm.getChestinfo());
        Paits.setText(nm.getWidth());
        Width.setText(nm.getThigh());
        Thigh.setText(nm.getKnee());
        Chest.setText(nm.getPocketsinfo());
        Instream1.setText(nm.getCalf());
        etAddress.setText(nm.getAddress());
        etHips.setText(nm.getHips());
        etSI.setText(nm.getAnkelhem());
        etSI2.setText(nm.getShirtoutseam());
        etS3.setText(nm.getShirtinseam());
        String en=nm.getImgpath();
        byte[] decodedString = Base64.decode(en, Base64.DEFAULT);
        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        imageView.setImageBitmap(decodedByte);




        //String en=nm.getImgpath();
       // byte[] decodedString = Base64.decode(en, Base64.DEFAULT);
       // Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
       // imageView.setImageBitmap(decodedByte);

        mDatabase = FirebaseDatabase.getInstance().getReference().child("PendingOrdersForTailor");




    }

    public static String formatDayMonthYear(Date date) {
        SimpleDateFormat FORMAT_DAY_MONTH_YEAR = new SimpleDateFormat("dd MMM yyyy", Locale.US);

        return FORMAT_DAY_MONTH_YEAR.format(date);
    }





    private void chooseImage() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK
                && data != null && data.getData() != null )
        {
            filePath = data.getData();
            try {
                bmp = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                imageView.setImageBitmap(bmp);
                bos = new ByteArrayOutputStream();
                bmp.compress(Bitmap.CompressFormat.JPEG, 100, bos);
                bt = bos.toByteArray();
                encodeString = Base64.encodeToString(bt, Base64.DEFAULT);
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }
    }

    public SimpleDateFormat getDefaultDateFormat() {
        return DMY_TIME_SLASH_FORMAT;
    }
    public String formatTimestamp(long timestamp) {
        return getDefaultDateFormat().format(new Date(timestamp));
    }









}