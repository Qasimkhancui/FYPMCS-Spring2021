package com.example.smarttailoringservices;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import androidx.appcompat.app.AppCompatActivity;

public class Tailor_Dashboard extends AppCompatActivity {
    private FirebaseAuth firebaseAuth;
    private FirebaseDatabase myData;
    private DatabaseReference mRef;
    private Button button_Logout,btnConfirmedOrders,btnEdit,btnTailorHistory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tailor__dashboard);
        button_Logout=(Button)findViewById(R.id.button_logout);
        btnConfirmedOrders=findViewById(R.id.btnConfirmed);
        btnEdit=findViewById(R.id.buttonExit1);
        btnTailorHistory=findViewById(R.id.buttonShare2);
        firebaseAuth=FirebaseAuth.getInstance();
        myData=FirebaseDatabase.getInstance();
        mRef=myData.getReference();
        btnTailorHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent=new Intent(Tailor_Dashboard.this,HistoryOptionsonTailorSide.class);
                startActivity(intent);

            }
        });

        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Tailor_Dashboard.this,UniformEditOrdersonTailorSide.class);
                startActivity(intent);

            }
        });
        btnConfirmedOrders.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Tailor_Dashboard.this,UniformConfirmOrdersonTailorSide.class);
                startActivity(intent);
            }
        });

        button_Logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                firebaseAuth.signOut();
                finish();
                Toast.makeText(Tailor_Dashboard.this, "Logout Successful", Toast.LENGTH_SHORT).show();

            }
        });
}

    public void btn_Profi(View view) {
        Intent intent=new Intent(Tailor_Dashboard.this, Tailor_Profile.class);
        startActivity(intent);    }

    public void btnOrd1(View view) {
        Intent intent=new Intent(Tailor_Dashboard.this,TailorOptionsforPendingOrders.class);
        startActivity(intent);
    }
}