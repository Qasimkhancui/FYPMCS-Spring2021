package com.example.smarttailoringservices;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class Tailor_SignUp extends AppCompatActivity {
    private EditText uname, phone, sspecialization, eexperience, ddaily_order, sshope_location,uemail, upassword, uconfirmpassword;
    private Button btn_reg,btnImg;
    private FirebaseAuth myAuth;
    FirebaseDatabase Database;
    DatabaseReference DatabaseRef;
    Tailor_Pro_Help tprofile;
    private final int PICK_IMAGE_REQUEST = 71;
    ImageView ivTailor;
    private Bitmap bmp ;
    ByteArrayOutputStream bos;
    byte[] bt ;
    String encodeString;
    private Uri filePath;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tailor__sign_up);
        uname = findViewById(R.id.user_name);
        phone =  findViewById(R.id.et_phone);
        sspecialization =  findViewById(R.id.special_lization);
        eexperience = findViewById(R.id.expe_rience);
        ddaily_order =  findViewById(R.id.daily_order);
        sshope_location =  findViewById(R.id.et_location);
        uemail = findViewById(R.id.et_Email);
        upassword = findViewById(R.id.et_Passwordd);
        uconfirmpassword = findViewById(R.id.et_confirmpassword);

        btn_reg = (Button) findViewById(R.id.et_register);
        btnImg=findViewById(R.id.btnImg);
        ivTailor=findViewById(R.id.ivTailor);
        myAuth = FirebaseAuth.getInstance();
        Database= FirebaseDatabase.getInstance();
        btnImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                chooseImage();
            }
        });

        DatabaseRef=Database.getReference();
        btn_reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String UserNmae=uname.getText().toString().trim();
                String Phone = phone.getText().toString().trim();
                String Specialization = sspecialization.getText().toString().trim();
                String Experience = eexperience.getText().toString().trim();
                final String Daily_Order = ddaily_order.getText().toString().trim();
                String Shope_location = sshope_location.getText().toString().trim();
                String Email = uemail.getText().toString().trim();
                String Password = upassword.getText().toString().trim();
                String ConfirmPassword=uconfirmpassword.getText().toString().trim();
                if(bmp==null){
                    Toast.makeText(Tailor_SignUp.this, "Please Select Profile Image", Toast.LENGTH_SHORT).show();
                    return;
                }

                if(UserNmae.isEmpty()){
                    uname.setError("Enter Name");
                    uname.requestFocus();
                    return;
                }
                if(Phone.isEmpty()){
                    phone.setError("Enter Phone No");
                    phone.requestFocus();
                    return;
                }
                if(Specialization.isEmpty()){
                    sspecialization.setError("Enter Specialization");
                    sspecialization.requestFocus();
                    return;
                }

                if(Experience.isEmpty()){
                    eexperience.setError("Enter Experience");
                    eexperience.requestFocus();
                    return;
                }
                if(Daily_Order.isEmpty()){
                    ddaily_order.setError("Enter Daily Order");
                    ddaily_order.requestFocus();
                    return;
                }

                if(Shope_location.isEmpty()){
                    sshope_location.setError("Enter Shope Location");
                    sshope_location.requestFocus();
                    return;
                }
                if(Email.isEmpty()){
                    uemail.setError("Enter Email");
                    uemail.requestFocus();
                    return;
                }
                if(Password.isEmpty()){
                    upassword.setError("Enter Password");
                    upassword.requestFocus();
                    return;
                }
                if(ConfirmPassword.isEmpty()) {
                    uconfirmpassword.setError("Enter ConfirmPassword");
                    uconfirmpassword.requestFocus();
                    return;
                }


                    if (!Password.equals(ConfirmPassword)) {
                        Toast.makeText(Tailor_SignUp.this, "Password does not match with confirm Password", Toast.LENGTH_SHORT).show();
                        return;
                    }

                myAuth.createUserWithEmailAndPassword(Email, Password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            String Role="Tailor";
                            String userId=myAuth.getCurrentUser().getUid();
                            String tailor_name=uname.getText().toString().trim();
                            String phone_no=phone.getText().toString().trim();
                            String specialization=sspecialization.getText().toString().trim();
                            String experience=eexperience.getText().toString().trim();
                            String daily_order=ddaily_order.getText().toString().trim();
                            String shope_location=sshope_location.getText().toString().trim();
                            String temail=uemail.getText().toString().trim();
                            DatabaseRef.child("User").child(userId).child("Role").setValue(Role);
                            DatabaseRef.child("User").child(userId).child("Username").setValue(tailor_name);


                             tprofile=new Tailor_Pro_Help(tailor_name, phone_no, specialization, experience, daily_order, shope_location,temail,encodeString);
                            DatabaseRef.child("Record").child("Tailor").child(tailor_name).setValue(tprofile);
                            Toast.makeText(Tailor_SignUp.this, "Registration Complete", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(Tailor_SignUp.this, Login_Screen.class));
                        } else {
                            Toast.makeText(Tailor_SignUp.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }

        });


    }

    private void chooseImage() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);

    }



    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK
                && data != null && data.getData() != null )
        {
            filePath = data.getData();
            try {
                bmp = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                Bitmap bmp2 = getResizedBitmap(bmp, 1000);

                ivTailor.setImageBitmap(bmp);
                bos = new ByteArrayOutputStream();
                bmp2.compress(Bitmap.CompressFormat.JPEG, 100, bos);
                bt = bos.toByteArray();
                encodeString = Base64.encodeToString(bt, Base64.DEFAULT);
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }
    }

    public Bitmap getResizedBitmap(Bitmap image, int maxSize) {
        int width = image.getWidth();
        int height = image.getHeight();

        float bitmapRatio = (float)width / (float) height;
        if (bitmapRatio > 1) {
            width = maxSize;
            height = (int) (width / bitmapRatio);
        } else {
            height = maxSize;
            width = (int) (height * bitmapRatio);
        }
        return Bitmap.createScaledBitmap(image, width, height, true);
    }


}



