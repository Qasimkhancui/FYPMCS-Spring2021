package com.example.smarttailoringservices;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.gson.Gson;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class User_Order extends AppCompatActivity {
    EditText etAddress, Collor, Becipes, Back, Button1, Chest, Arms, Pockets, Paits, Width, Thigh, Knee, Calf, AnkelHem, Hipes, Outstream1, Instream1;
    android.widget.Button btn_submit, btnpickImg;
    FirebaseDatabase db;
    String tailorUsername;
    DatabaseReference mydata, ref;
    String Address, CollorVal, BecipesVal, BackVal, ButtonVal, ChestVal, ArmsVal, PocketsVal, PaitsVal, WidthVal, ThighVal, KneeVal, CalfVal, AnkelHemVal, HipesVal, OutstreamVal, InstreamVal;
    String uniqueKey;
    SharedPreferences mPrefs;

    Bitmap bmp;
    ByteArrayOutputStream bos;
    byte[] bt;
    String encodeString;
    private Uri filePath;

    Location gps_loc;
    Location network_loc;
    Location final_loc;
    double longitude;
    double latitude;

    LocationManager locationManager;

    TextView txtAddress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user__order);
        mPrefs = getPreferences(MODE_PRIVATE);


        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);



        Intent intent = getIntent();
        tailorUsername = intent.getStringExtra("tailorUsername");

        Collor = (EditText) findViewById(R.id.collor_info);
        Becipes = findViewById(R.id.Becipes_info);
        Back = findViewById(R.id.back_info);
        Button1 = findViewById(R.id.button_info);
        Chest = findViewById(R.id.chest_info);
        Arms = findViewById(R.id.arms_info);
        Pockets = findViewById(R.id.pockets_info);
        Paits = findViewById(R.id.pait_info);
        //Collor = findViewById(R.id.collor_info);
        Width = findViewById(R.id.width_info);
        Thigh = findViewById(R.id.thigh_info);
        Knee = findViewById(R.id.knee_info);
        Calf = findViewById(R.id.calf_id);
        AnkelHem = findViewById(R.id.ankel_hem);
        Hipes = findViewById(R.id.hipes_info);
        Outstream1 = findViewById(R.id.out_seam);
        Instream1 = findViewById(R.id.in_seam);
        btn_submit = (Button) findViewById(R.id.btn_submit);
        etAddress = findViewById(R.id.etAddress);
        btnpickImg = findViewById(R.id.btnPickimg);

        Gson gson = new Gson();
        String json = mPrefs.getString("MyObject", "");
        OrderClass obj = gson.fromJson(json, OrderClass.class);
        if (obj != null) {
            Collor.setText(obj.getCollarinfo());
            Becipes.setText(obj.getBicepsinfo());
            Back.setText(obj.getBackinfo());
            Chest.setText(obj.getChestinfo());
            Width.setText(obj.getWidth());
            Thigh.setText(obj.getThigh());
            Knee.setText(obj.getKnee());
            Calf.setText(obj.getCalf());
            AnkelHem.setText(obj.getAnkelhem());
            Hipes.setText(obj.getHips());
            Pockets.setText(obj.getPocketsinfo());
            Outstream1.setText(obj.getShirtoutseam());
            Instream1.setText(obj.getShirtoutseam());
            Arms.setText(obj.getSleevesinfo());
            Button1.setText(obj.getButoninfo());
            Paits.setText(obj.getStomachinfo());
            etAddress.setText(obj.getAddress());
            encodeString = obj.getImgpath();


        }
        btnpickImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                chooseImage();

            }
        });

        ref = FirebaseDatabase.getInstance().getReference().child("PendingOrdersForUser").push();
        uniqueKey = ref.getKey();

        mydata = FirebaseDatabase.getInstance().getReference();
        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CollorVal = Collor.getText().toString();
                BecipesVal = Becipes.getText().toString();
                BackVal = Back.getText().toString();
                ButtonVal = Button1.getText().toString();
                ChestVal = Chest.getText().toString();
                ArmsVal = Arms.getText().toString();
                PocketsVal = Pockets.getText().toString();
                PaitsVal = Paits.getText().toString();
                WidthVal = Width.getText().toString();
                ThighVal = Thigh.getText().toString();
                KneeVal = Knee.getText().toString();
                Address = etAddress.getText().toString();

                CalfVal = Calf.getText().toString();
                AnkelHemVal = AnkelHem.getText().toString();
                HipesVal = Hipes.getText().toString();
                OutstreamVal = Outstream1.getText().toString();
                InstreamVal = Instream1.getText().toString();

                String address = etAddress.getText().toString().trim();
                if (address.isEmpty()) {
                    etAddress.setError("Address must be entered!");
                    etAddress.requestFocus();
                } else {
                    addOrder();
                }
            }
        });

        getCurrentLoc();





        etAddress.setText(getLocationFromAddress(latitude,longitude));
    }

    private void addOrder() {
        long unId = new Date().getTime();
        String unId1 = String.valueOf(unId);
        OrderClass order = new OrderClass(CollorVal, BecipesVal, BackVal, ButtonVal, ChestVal, ArmsVal, PocketsVal, PaitsVal, WidthVal, ThighVal, KneeVal, CalfVal, AnkelHemVal, HipesVal, OutstreamVal, InstreamVal, unId1, Address, encodeString);

        SharedPreferences.Editor prefsEditor = mPrefs.edit();
        Gson gson = new Gson();
        String json = gson.toJson(order);
        prefsEditor.putString("MyObject", json);
        prefsEditor.commit();


        SharedPreferences prefs = getSharedPreferences(
                "userName", Context.MODE_PRIVATE);
        String userNameKey = "usName";
        String userName1 = prefs.getString(userNameKey, "");

        mydata.child("HierarchyPendingOrdersForUser").child(userName1).child(tailorUsername).setValue(tailorUsername);
        mydata.child("HierarchyPendingOrdersForTailor").child(tailorUsername).child(userName1).setValue(userName1);

        //Saving the Artist
        mydata.child("PendingOrdersForUser").child(userName1).child(tailorUsername).child(unId1).setValue(order);
        mydata.child("PendingOrdersForTailor").child(tailorUsername).child(userName1).child(unId1).setValue(order);

        Toast.makeText(User_Order.this, "Your Order has been delivered Successfully", Toast.LENGTH_SHORT).show();

    }

    private void chooseImage() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), 71);
    }

    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 71 && resultCode == RESULT_OK
                && data != null && data.getData() != null) {
            filePath = data.getData();
            try {
                bmp = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                Bitmap bmp2 = getResizedBitmap(bmp, 1000);

                //ivuser.setImageBitmap(bmp);
                bos = new ByteArrayOutputStream();
                bmp2.compress(Bitmap.CompressFormat.JPEG, 100, bos);
                bt = bos.toByteArray();
                encodeString = Base64.encodeToString(bt, Base64.DEFAULT);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    public Bitmap getResizedBitmap(Bitmap image, int maxSize) {
        int width = image.getWidth();
        int height = image.getHeight();

        float bitmapRatio = (float) width / (float) height;
        if (bitmapRatio > 1) {
            width = maxSize;
            height = (int) (width / bitmapRatio);
        } else {
            height = maxSize;
            width = (int) (height * bitmapRatio);
        }
        return Bitmap.createScaledBitmap(image, width, height, true);
    }


    public void getCurrentLoc() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_NETWORK_STATE) != PackageManager.PERMISSION_GRANTED) {

            return;
        }

        try {

            gps_loc = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            network_loc = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);

        } catch (Exception e) {
            e.printStackTrace();
        }

        if (gps_loc != null) {
            final_loc = gps_loc;
            latitude = final_loc.getLatitude();
            longitude = final_loc.getLongitude();
        } else if (network_loc != null) {
            final_loc = network_loc;
            latitude = final_loc.getLatitude();
            longitude = final_loc.getLongitude();
        } else {
            latitude = 0.0;
            longitude = 0.0;
        }
    }

    public String getLocationFromAddress(double latitude, double longitude) {
        Geocoder geocoder = new Geocoder(User_Order.this, Locale.getDefault());
        String result = null;
        try {
            List<android.location.Address> addressList = geocoder.getFromLocation(latitude, longitude, 1);
            if (addressList != null && addressList.size() > 0) {
                Address address = addressList.get(0);
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < address.getMaxAddressLineIndex(); i++) {
                    sb.append(address.getAddressLine(i)); //.append("\n");
                }
                if (address.getSubThoroughfare() != null) {
                    sb.append(address.getSubThoroughfare()).append(" , ");
                }
                if (address.getThoroughfare() != null) {
                    sb.append(address.getThoroughfare()).append(" , ");
                }
                if (address.getSubLocality() != null) {
                    sb.append(address.getSubLocality()).append(" , ");
                }
                if (address.getLocality() != null) {
                    sb.append(address.getLocality()).append(" , ");
                }
                sb.append(address.getCountryName());
                result = sb.toString();
            }
        } catch (IOException e) {
            Log.e("Location Address Loader", "Unable connect to Geocoder", e);
        }
        return result;
    }

}