package com.example.smarttailoringservices;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.gson.Gson;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Date;


public class School_Order extends AppCompatActivity {
    private final int PICK_IMAGE_REQUEST = 71;
    EditText etSN,etQ,etG;
    ImageView imageView;
    SchoolClass schoolClass;
    DatabaseReference mydata,ref;
    String tailorUsername;
    SharedPreferences  mPrefs2 ;




    Bitmap bmp ;
    ByteArrayOutputStream bos;
    byte[] bt ;
    String encodeString;
    private Uri filePath;
    Button button1,btnUpload;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_school__order);
        imageView=findViewById(R.id.imageView6);
        button1=findViewById(R.id.btn_select);
        etG=findViewById(R.id.etUniformGents);
        etQ=findViewById(R.id.etUniformQuantity);
        etSN=findViewById(R.id.etSchoolName);
        btnUpload=findViewById(R.id.btn_upload);
        schoolClass=new SchoolClass();
        mPrefs2 = getPreferences(MODE_PRIVATE);

        Gson gson = new Gson();
        String json = mPrefs2.getString("MyObject2", "");
        SchoolClass obj = gson.fromJson(json, SchoolClass.class);
        if (obj!=null){
        etQ.setText(obj.getOrderQuantity());
        etSN.setText(obj.getSchoolName());
        etG.setText(obj.getOrderGents());
        encodeString=obj.getUniformImg();
        byte[] decodedString = Base64.decode(encodeString, Base64.DEFAULT);
        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        imageView.setImageBitmap(decodedByte);}


        Intent intent=getIntent();
        tailorUsername=intent.getStringExtra("tailorUsername");

        mydata = FirebaseDatabase.getInstance().getReference();


        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);



                    }
        });

        btnUpload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                long unId=new Date().getTime();
                String unId1=String.valueOf(unId);
                schoolClass.setOrderGents(etG.getText().toString());
                schoolClass.setOrderQuantity(etQ.getText().toString());
                schoolClass.setSchoolName(etSN.getText().toString());
                schoolClass.setOrdernumber(unId1);
                schoolClass.setUniformImg(encodeString);
                String gents=etG.getText().toString().trim();
                SharedPreferences.Editor prefsEditor = mPrefs2.edit();
                Gson gson = new Gson();
                String json = gson.toJson(schoolClass);
                prefsEditor.putString("MyObject2", json);
                prefsEditor.commit();
                if(bmp==null) {
                    Toast.makeText(School_Order.this, "Please Select Design Image", Toast.LENGTH_SHORT).show();
                    return;
                }
                else if(gents.isEmpty()){
                    etG.setError("The Uniforms details must be entered");
                    etG.requestFocus();
                }
                else {
                    SharedPreferences prefs = getSharedPreferences(
                            "userName", Context.MODE_PRIVATE);
                    String userNameKey = "usName";
                    String userName1 = prefs.getString(userNameKey, "");

                    mydata.child("HierarchyPendingOrdersForUserUniform").child(userName1).child(tailorUsername).setValue(tailorUsername);
                    mydata.child("HierarchyPendingOrdersForTailorUniform").child(tailorUsername).child(userName1).setValue(userName1);

                    //Saving the Artist
                    mydata.child("PendingOrdersForUserUniform").child(userName1).child(tailorUsername).child(unId1).setValue(schoolClass).addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Toast.makeText(School_Order.this, "Your order has delivered successfully", Toast.LENGTH_SHORT).show();

                        }
                    });
                    mydata.child("PendingOrdersForTailorUniform").child(tailorUsername).child(userName1).child(unId1).setValue(schoolClass);


                }


            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK
                && data != null && data.getData() != null )
        {
            filePath = data.getData();
            try {
                bmp = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                Bitmap bmp2 = getResizedBitmap(bmp, 800);

                imageView.setImageBitmap(bmp);
                bos = new ByteArrayOutputStream();
                bmp2.compress(Bitmap.CompressFormat.JPEG, 100, bos);
                bt = bos.toByteArray();
                encodeString = Base64.encodeToString(bt, Base64.DEFAULT);
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }


    }

    public Bitmap getResizedBitmap(Bitmap image, int maxSize) {
        int width = image.getWidth();
        int height = image.getHeight();

        float bitmapRatio = (float)width / (float) height;
        if (bitmapRatio > 1) {
            width = maxSize;
            height = (int) (width / bitmapRatio);
        } else {
            height = maxSize;
            width = (int) (height * bitmapRatio);
        }
        return Bitmap.createScaledBitmap(image, width, height, true);
    }
}