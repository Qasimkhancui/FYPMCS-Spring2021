package com.example.smarttailoringservices;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class EditingSchoolOrderActivity extends AppCompatActivity {
    private EditText etNumber,etSchoolName,etGent,etNewDate;
    private DatabaseReference mDatabase,postRef;
    private Button btnAdd;

    ImageView imageView;
    private String savePath,appDate;
    private long dateIssue;
    private long dateExpire;
    Bitmap bmp ;
    ByteArrayOutputStream bos;
    byte[] bt ;
    String encodeString;
    private Uri filePath;
    String inputValue;
    private final int PICK_IMAGE_REQUEST = 71;
    SimpleDateFormat DMY_TIME_SLASH_FORMAT;
    SharedPreferences prefs;
    String userName1,userName2;
    SchoolClass nm;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editing_schools);
        btnAdd=findViewById(R.id.btnComplete4);
        etNewDate=findViewById(R.id.etNewDate);

         prefs = getSharedPreferences(
                "userName1", Context.MODE_PRIVATE);
        String userNameKey = "usName1";
         userName1=prefs.getString(userNameKey,"");
        prefs = getSharedPreferences(
                "userName", Context.MODE_PRIVATE);
        String userNameKey1 = "usName";
        userName2=prefs.getString(userNameKey1,"");




        DMY_TIME_SLASH_FORMAT = new SimpleDateFormat("d/M/yyyy", Locale.US);


        etNumber=findViewById(R.id.OrderNum4);
        etGent=findViewById(R.id.OrderGents4);
        etSchoolName=findViewById(R.id.ScoolName4);
        imageView=findViewById(R.id.ivUniform4);







        Intent intent=getIntent();
        nm= (SchoolClass) intent.getSerializableExtra("model");


        etNumber.setText(nm.getOrdernumber());
        etSchoolName.setText(nm.getSchoolName());
        etGent.setText(nm.getOrderGents());
        String en=nm.getUniformImg();
        byte[] decodedString = Base64.decode(en, Base64.DEFAULT);
        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        imageView.setImageBitmap(decodedByte);

        etNewDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Calendar calendar = Calendar.getInstance();
                DatePickerDialog datePickerDialog =
                        new DatePickerDialog(EditingSchoolOrderActivity.this, new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view1, int year, int month, int dayOfMonth) {
                                Calendar calendar1 = Calendar.getInstance();
                                calendar1.set(Calendar.YEAR, year);
                                calendar1.set(Calendar.MONTH, month);
                                calendar1.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                                etNewDate.setText(formatDayMonthYear(calendar1.getTime()));
                                appDate = formatDayMonthYear(calendar1.getTime());


                                dateExpire = calendar1.getTimeInMillis();
                            }
                        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH),
                                calendar.get(Calendar.DAY_OF_MONTH));
                datePickerDialog.show();


            }
        });





        //String en=nm.getImgpath();
       // byte[] decodedString = Base64.decode(en, Base64.DEFAULT);
       // Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
       // imageView.setImageBitmap(decodedByte);

        mDatabase = FirebaseDatabase.getInstance().getReference().child("PendingOrdersForTailor");

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              //  if (validateInput())
                    addArtist();
            }
        });



    }

    public static String formatDayMonthYear(Date date) {
        SimpleDateFormat FORMAT_DAY_MONTH_YEAR = new SimpleDateFormat("dd MMM yyyy", Locale.US);

        return FORMAT_DAY_MONTH_YEAR.format(date);
    }





    private void chooseImage() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK
                && data != null && data.getData() != null )
        {
            filePath = data.getData();
            try {
                bmp = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                imageView.setImageBitmap(bmp);
                bos = new ByteArrayOutputStream();
                bmp.compress(Bitmap.CompressFormat.JPEG, 20, bos);
                bt = bos.toByteArray();
                encodeString = Base64.encodeToString(bt, Base64.DEFAULT);
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }
    }

    public SimpleDateFormat getDefaultDateFormat() {
        return DMY_TIME_SLASH_FORMAT;
    }
    public String formatTimestamp(long timestamp) {
        return getDefaultDateFormat().format(new Date(timestamp));
    }



    private void addArtist() {
        postRef = FirebaseDatabase.getInstance().getReference();
        postRef.child("Notification").child(userName1).child("Title").child(etNumber.getText().toString()).removeValue();

        postRef.child("Notification").child(userName1).child("Title").child(etNumber.getText().toString()).setValue("Your Order number"+etNumber.getText().toString()+" has been changed. New Date "+appDate);


        Intent intent=new Intent(EditingSchoolOrderActivity.this, ShowingConfirmedUsersforTailorUniform.class);
        startActivity(intent);
        finish();

     /*   String name = etFn.getText().toString();
        String genre = etLn.getText().toString();
        String id = etLicNum.getText().toString();
        Artist artist = new Artist(id, name, genre);

        //Saving the Artist
        mDatabase.child(id).setValue(artist);*/
    }






}