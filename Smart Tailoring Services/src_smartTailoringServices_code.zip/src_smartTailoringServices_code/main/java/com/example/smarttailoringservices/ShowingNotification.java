package com.example.smarttailoringservices;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class ShowingNotification extends AppCompatActivity
{
   RecyclerView recview;
   showingnotificationadapter adapter;
    SharedPreferences prefs;
    String userName1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_showing_notifications);
        Intent intent=getIntent();
        String clientName=intent.getStringExtra("artname");
        prefs = getSharedPreferences(
                "userName", Context.MODE_PRIVATE);
        String userNameKey = "usName";
        userName1=prefs.getString(userNameKey,"");

        recview=(RecyclerView)findViewById(R.id.recview8);
        recview.setLayoutManager(new LinearLayoutManager(this));
        //FirebaseDatabase.getInstance().setPersistenceEnabled(true);


        FirebaseRecyclerOptions<String> options =
                new FirebaseRecyclerOptions.Builder<String>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("Notification").child(userName1).child("Title"), String.class)
                        .build();


        adapter=new showingnotificationadapter(options);
        recview.setAdapter(adapter);


    }

    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}