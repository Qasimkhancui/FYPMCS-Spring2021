package com.example.smarttailoringservices;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class Choose_Order_Category extends AppCompatActivity {
    private static final int PERMISSIONS_REQUEST_LOCATION_CURRENT = 101;
    private Button btn;
    String tailorId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose__order__category);
        btn=findViewById(R.id.btn_org);
        Intent intent=getIntent();
        tailorId=intent.getStringExtra("tailorUsername");
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Choose_Order_Category.this,Choose_Order_Category.class);
                intent.putExtra("tailorUsername",tailorId);

                startActivity(intent);
            }
        });
    }
public void btn_school_order(View view){
        Intent intent =new Intent(Choose_Order_Category.this,School_Order.class);
    intent.putExtra("tailorUsername",tailorId);

    startActivity(intent);
}

    public void btn_user(View view) {

        if (ContextCompat.checkSelfPermission(Choose_Order_Category.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(Choose_Order_Category.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, PERMISSIONS_REQUEST_LOCATION_CURRENT);
        }
        else{
            Intent intent=new Intent(Choose_Order_Category.this,User_Order.class);
            intent.putExtra("tailorUsername",tailorId);

            startActivity(intent);
        }


    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if(requestCode==PERMISSIONS_REQUEST_LOCATION_CURRENT){
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Intent intent=new Intent(Choose_Order_Category.this,User_Order.class);
                intent.putExtra("tailorUsername",tailorId);

                startActivity(intent);
            }
        }
    }
}
