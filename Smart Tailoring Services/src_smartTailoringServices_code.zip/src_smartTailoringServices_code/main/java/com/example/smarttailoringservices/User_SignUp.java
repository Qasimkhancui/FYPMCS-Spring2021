package com.example.smarttailoringservices;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class User_SignUp extends AppCompatActivity {
    private EditText user_name, e_mail, p_hone, a_ddress, p_assword, confirm_password;
    private Button regbutton;
    private Button btImg;
    private FirebaseAuth firebaseAuth;
    FirebaseDatabase Database;
    DatabaseReference DatabaseRef;
    private final int PICK_IMAGE_REQUEST = 71;
    ImageView ivuser;
    Bitmap bmp ;
    ByteArrayOutputStream bos;
    byte[] bt ;
    String encodeString;
    private Uri filePath;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user__sign_up);
        setupUIVews();
        firebaseAuth = FirebaseAuth.getInstance();
        Database = FirebaseDatabase.getInstance();
        DatabaseRef = Database.getReference();
        btImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                chooseImage();
            }
        });
        regbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Username = user_name.getText().toString();
                final String Email = e_mail.getText().toString();
                String Password = p_assword.getText().toString();
                String ConfirmPassword = confirm_password.getText().toString();
                if(bmp==null) {
                    Toast.makeText(User_SignUp.this, "Please Select Profile Image", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (Username.isEmpty()) {
                    user_name.setError("Enter Username");
                    user_name.requestFocus();
                    return;
                }
                if (Email.isEmpty()) {
                    e_mail.setError("Enter Email");
                    e_mail.requestFocus();
                    return;
                }
                if (Password.isEmpty()) {
                    p_assword.setError("Enter Password");
                    p_assword.requestFocus();
                    return;
                }
                if (ConfirmPassword.isEmpty()) {
                    confirm_password.setError("Enter ConfirmPassword");
                    confirm_password.requestFocus();
                    return;
                }
                if (!Password.equals(ConfirmPassword)) {
                    Toast.makeText(User_SignUp.this, "Password does not match with Confirm Password", Toast.LENGTH_SHORT).show();
                    return;
                }
                firebaseAuth.createUserWithEmailAndPassword(Email, Password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            String Role = "Client";
                            String uname = user_name.getText().toString();
                            String email = e_mail.getText().toString();
                            String phone = p_hone.getText().toString();
                            String address = a_ddress.getText().toString();

                            String userId = firebaseAuth.getCurrentUser().getUid();
                            DatabaseRef.child("User").child(userId).child("Role").setValue(Role);
                            DatabaseRef.child("User").child(userId).child("Username").setValue(uname);

                            Profile uprofile = new Profile(uname, email, phone, address,encodeString);

                            DatabaseRef.child("Record").child("Client").child(uname).setValue(uprofile);
                            Toast.makeText(User_SignUp.this, "Registration Complete", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(User_SignUp.this, Login_Screen.class));
                        } else {
                            Toast.makeText(User_SignUp.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }


        });
    }
    private void chooseImage() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK
                && data != null && data.getData() != null )
        {
            filePath = data.getData();
            try {
                bmp = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                Bitmap bmp2 = getResizedBitmap(bmp, 1000);

                ivuser.setImageBitmap(bmp);
                bos = new ByteArrayOutputStream();
                bmp2.compress(Bitmap.CompressFormat.JPEG, 100, bos);
                bt = bos.toByteArray();
                encodeString = Base64.encodeToString(bt, Base64.DEFAULT);
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }
    }

    public Bitmap getResizedBitmap(Bitmap image, int maxSize) {
        int width = image.getWidth();
        int height = image.getHeight();

        float bitmapRatio = (float)width / (float) height;
        if (bitmapRatio > 1) {
            width = maxSize;
            height = (int) (width / bitmapRatio);
        } else {
            height = maxSize;
            width = (int) (height * bitmapRatio);
        }
        return Bitmap.createScaledBitmap(image, width, height, true);
    }



    private void setupUIVews() {
        user_name = (EditText) findViewById(R.id.etusername);
        e_mail = (EditText) findViewById(R.id.etEmail);
        p_assword = (EditText) findViewById(R.id.etPasswordd);
        p_hone=(EditText) findViewById(R.id.etphone);
        a_ddress=(EditText)findViewById(R.id.etlocation);
        confirm_password = (EditText) findViewById(R.id.etconfirmpassword);
        btImg=(Button)findViewById(R.id.btnuImg);
        ivuser=(ImageView)findViewById(R.id.btnuuimg);
        regbutton = (Button) findViewById(R.id.etregister);
    }

}