package com.example.smarttailoringservices;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class ShowingConfirmedUsersforTailor extends AppCompatActivity
{
   RecyclerView recview;
   viewingconfirmeduserontailoradapter adapter;
    private SearchView searchView;
    FirebaseRecyclerOptions<String> options;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_showing_confirmedusers_tailor);
        Intent intent=getIntent();
        String clientName=intent.getStringExtra("artname");
        searchView = (SearchView) findViewById(R.id.searchView11);

        SharedPreferences prefs = getSharedPreferences(
                "userName", Context.MODE_PRIVATE);
        String userNameKey = "usName";
        String userName1=prefs.getString(userNameKey,"");


        recview=(RecyclerView)findViewById(R.id.recview11);
        recview.setLayoutManager(new LinearLayoutManager(this));
        //FirebaseDatabase.getInstance().setPersistenceEnabled(true);


         options =
                new FirebaseRecyclerOptions.Builder<String>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("HierarchyConfirmedOrderForTailor").child(userName1), String.class)
                        .build();


        adapter=new viewingconfirmeduserontailoradapter(options);
        recview.setAdapter(adapter);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }
            @Override
            public boolean onQueryTextChange(String newText) {

                refreshList(newText);


                return true;
            }
        });



    }

    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }


    public void refreshList(String search){
        String pquery = search.toLowerCase();
        Query sQuery = FirebaseDatabase.getInstance().getReference().child("Record").child("Client").orderByChild("uname").startAt(pquery).endAt(pquery+ "\uf8ff");

        options =
                new FirebaseRecyclerOptions.Builder<String>()
                        .setQuery(/*FirebaseDatabase.getInstance().getReference().child("ConsumerProfiles")*/sQuery, String.class)
                        .build();


        adapter=new viewingconfirmeduserontailoradapter(options);
        recview.setAdapter(adapter);
        adapter.startListening();
    }

}