package com.example.smarttailoringservices;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class UniformEditOrdersonTailorSide extends AppCompatActivity {
    private Button btnConfirmedUser,btnConfirmedUniform;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_uniform_edit_orderson_tailor_side);
        btnConfirmedUniform=findViewById(R.id.btnConfirmedUniform2);
        btnConfirmedUser=findViewById(R.id.btnConfirmedUser2);

        btnConfirmedUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(UniformEditOrdersonTailorSide.this,ShowingConfirmedUsersforTailorEdit.class);
                startActivity(intent);

            }
        });
        btnConfirmedUniform.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent=new Intent(UniformEditOrdersonTailorSide.this,ShowingConfirmedUsersforTailorUniformEdit.class);
                startActivity(intent);

            }
        });
    }
}