﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PableRules : MonoBehaviour
{
	public GameObject player;
	public int pableInBox;
	public GameObject panelMenu;
	GameObject Canvas;
    // Start is called before the first frame update
    void Start()
    {
        Canvas = GameObject.Find("Canvas");
        Transform[] child = Canvas.GetComponentsInChildren<Transform>(true);
        foreach (Transform c in child)
        {
            if (c.name == "Panel")
                panelMenu = c.gameObject;
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    
    void OnTriggerEnter(Collider col){
    	if(col.tag != GameSetup.GS.round.ToString() || col.tag == "bound"){
    		//Time.timeScale = 0;
    		//panelMenu.SetActive(true);
    		print("Please Restart");
    	}
    	if(col.tag == GameSetup.GS.round.ToString()){
    		pableInBox = int.Parse(col.tag);
    		print("Pable is in Box "+ pableInBox);
    	}
    }
}
