﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using Photon.Pun;
using Photon.Pun.UtilityScripts;
using Photon.Realtime;
using UnityEngine;
using UnityEngine.UI;
using Random = UnityEngine.Random;

public enum Players_Number {Two}

public class MasterScript : MonoBehaviourPun, IPunTurnManagerCallbacks
{
    public static MasterScript Instance { get; private set; }
    #region Finding Number Of Players And Assigning Number
    [Space(10)]
    [Header("Finding Number Of Players And Assigning Number")]
    [Space(10)]
    public Players_Number PlayerNumber;
    public int Players,MyNumber;
    public List<string> PhotonIDs,Names;
    public string myname;
     public string[] Username_list;
    public Text Mytext; 
    public Text[] Othertext;
    public char x;
    public int otheravatarindex;
    [PunRPC]
    public void AddPlayer(string str,string name)
    {
        
        ShowPlayersInTheRoom();
        Debug.Log(str);
        Players++;
        PhotonIDs.Add(str);
        Names.Add(name);
        Debug.Log(name);
        if (Players == 2) { PlayerNumber= Players_Number.Two; }
        if( Players== PhotonNetwork.PlayerList.Length)
        {
            if(PlayerNumber==Players_Number.Two)
            {
                photonView.RPC("CheckMyNumber", RpcTarget.All, PhotonIDs[0], PhotonIDs[1]);
            }

            if (PlayerNumber == Players_Number.Two)
            {
                photonView.RPC("CheckMyname", RpcTarget.All, Names[0], Names[1]);

                photonView.RPC("ShowPlayersInTheRoom", RpcTarget.All);
            }
        }
    }
    [PunRPC]
    public void CheckMyNumber(string a,string b)
    {
        string MyId = PhotonNetwork.LocalPlayer.UserId;
        
        if (MyId==a)
            {
                MyNumber = 1;
            
            }
            if (MyId == b)
            {
                MyNumber = 2;
            }
    }
    [PunRPC]
    public void CheckMyname(string a, string b)
    {
        string Myname = PhotonNetwork.LocalPlayer.NickName;
        
        if (Myname == a)
        {
            myname = a;
            print("Player 1 : number Name" + myname);
            Mytext.text = MyNumber + myname;
        }
        if (Myname == b)
        {
            myname = b;
            print("Player 1 : number Name" + myname);
            Mytext.text = MyNumber + myname;
        }
    }
    [PunRPC]
    void ShowPlayersInTheRoom()
    {
        foreach (KeyValuePair<int, Player> playerInfo in PhotonNetwork.CurrentRoom.Players)
        {
            Debug.Log(playerInfo.Value.NickName + "Has Joined Now!!");
            if (playerInfo.Value.NickName == PhotonNetwork.NickName)
            {

            }
            else
            {
                Othertext[playerInfo.Key-1].text = playerInfo.Value.NickName;
                foreach (char checkchar in playerInfo.Value.NickName)
                {
                    x = checkchar;
                    print(x);
                }
                print("Index check" + playerInfo.Key);
            }
        }
    }
    #endregion
    private void Update()
    {
        
    }
    void Start()
    {
        //print(PhotonNetwork.NickName);
        
        Instance = this;
        Debug.Log(PhotonNetwork.PlayerList.Length);
        Players = 0;
        MyNumber = 0;
        PhotonIDs = new List<string>();
        //pp = PhotonNetwork.PlayerList;
        //foreach (Player item in pp)
        //{
        //    Debug.Log(item.ActorNumber + " " + item.UserId+" "+ PhotonNetwork.LocalPlayer.UserId);
        //}
        photonView.RPC("AddPlayer", RpcTarget.MasterClient, PhotonNetwork.LocalPlayer.UserId, PhotonNetwork.LocalPlayer.NickName);
        AddPlayersToTheList();
        _punTurnManager = GetComponent<PunTurnManager>();
        _punTurnManager.TurnManagerListener = this;
        //_punTurnManager.TurnDuration = 10f;
        ResultText.gameObject.SetActive(true);
        timeForNextTurn = _punTurnManager.TurnDuration;
        if (PhotonNetwork.IsMasterClient)
        {
            _punTurnManager.BeginTurn();
            isMyturn = true;
            //turnButton.interactable = true;
            // CoRoutine To Start First Turn
            StartCoroutine(I_StartTurn());
        }
        
        //LoadExpressions();
        NumberDone = new List<int>();
    }
    public List<string> Expressions;
    public List<int> NumberDone;
    public Text TurnText, ResultText;
    public bool PlayerHasWon = false;
    public Text winPanel, TT;

    //public Button turnButton;

    private PunTurnManager _punTurnManager;
    List<Player> playersInTheRoom = new List<Player>();
    [SerializeField]
    public bool isMyturn = false;
    float timeForNextTurn;

    //[SerializeField] private Text rematchText;
    private bool isRematchSelected;

    //[SerializeField] private Text playerTurnText;
 
    
    private void AddPlayersToTheList()
    {
        foreach (var VARIABLE in PhotonNetwork.CurrentRoom.Players)
        {
            playersInTheRoom.Add(VARIABLE.Value);
        }
        playersInTheRoom = playersInTheRoom.OrderBy(x => x.ActorNumber).ToList();
    }
    
    public void NextTurn()
    {
        _punTurnManager.SendMove("2", true);
        photonView.RPC("DoTurn", RpcTarget.MasterClient, PhotonNetwork.LocalPlayer);
    }

    [PunRPC]
    void DoTurn(Player player)
    {
        if (!PlayerHasWon)
        {
            AGAIN:
            int tempInt = Random.Range(0, Expressions.Count);
            if (NumberDone.Contains(tempInt))
            {
                goto AGAIN;
            }
            else
            {
                photonView.RPC("AddNumberAndShowText", RpcTarget.AllBufferedViaServer, tempInt, player);
            }
        }
    }

    [PunRPC]
    void AddNumberAndShowText(int number, Player player)
    {
        NumberDone.Add(number);
        TurnText.text = Expressions[number];
    }
    public void SomePlayerWon(Player player)
    {
        photonView.RPC("ShowPlayerWon", RpcTarget.AllBufferedViaServer, player);
    }
    [PunRPC]
    void ShowPlayerWon(Player player)
    {
        isMyturn = false;
        timeForNextTurn = 0;
        PlayerHasWon = true;
        winPanel.transform.parent.gameObject.SetActive(true);
        ResultText.text = player.NickName + " is WON!!..."; //
        if (player == PhotonNetwork.LocalPlayer)
        {
            winPanel.text = "You Won!!!!";
        }
        else
        {
            winPanel.text = "Player " + player.NickName + " Won the Game";
        }
    }

    [PunRPC]
    void SetTurnText(string str, Player player)
    {
        TT.text = player.NickName + "Listened\n" + str;
        StartCoroutine(EraseAfter());
    }

    IEnumerator EraseAfter()
    {
        yield return new WaitForSeconds(2.0f);
        TT.text = "";
        StopCoroutine(EraseAfter());
    }

    [PunRPC]
    void SetThePlayerTurn(Player player)
    {
        if (player == PhotonNetwork.LocalPlayer)
        {
            _punTurnManager.BeginTurn();
            //turnButton.interactable = true;
            isMyturn = true;
            StartCoroutine(I_StartTurn());
        }
        else
        {
            //turnButton.interactable = false;
            isMyturn = false;
        }
    }

    IEnumerator I_StartTurn()
    {
        timeForNextTurn = _punTurnManager.TurnDuration;
        ResultText.text = timeForNextTurn.ToString();
        while (isMyturn && timeForNextTurn > 0)
        {
            yield return new WaitForSeconds(1.0f);
            timeForNextTurn--;
            ResultText.text = timeForNextTurn.ToString();
        }

        OnPlayerFinished(PhotonNetwork.LocalPlayer, 0, null);
    }

    #region TurnManagerCallbacks

    public void OnTurnBegins(int turn)
    {
    }

    public void OnTurnCompleted(int turn)
    {
    }

    public void OnPlayerMove(Player player, int turn, object move)
    {
    }

    public void OnPlayerFinished(Player player, int turn, object move)
    {
        if (Equals(player, PhotonNetwork.LocalPlayer))
        {
            if (isMyturn)
            {
                isMyturn = false;
                ResultText.text = "";
                //turnButton.interactable = false;
                photonView.RPC("SetThePlayerTurn", RpcTarget.All, PhotonNetwork.LocalPlayer.GetNext());
            }
        }
    }


    public void OnTurnTimeEnds(int turn)
    {
    }

    #endregion

    public void CallNextPlayerTurnIfHeLeft(Player player)
    {
        Debug.LogError("Player left the Match Passing to next Player1111" + player.NickName);
        if (PhotonNetwork.CurrentRoom.PlayerCount > 1)
        {
            //photonView.RPC("SetThePlayerTurn", RpcTarget.All, player.GetNext());
            int index = playersInTheRoom.FindIndex(x => x.Equals(player));
            Debug.LogError("The Index is " + index);
            if (index != -1)
            {
                if (index + 1 == playersInTheRoom.Count)
                {
                    photonView.RPC("SetThePlayerTurn", RpcTarget.All, playersInTheRoom[0]);
                }
                else
                {
                    photonView.RPC("SetThePlayerTurn", RpcTarget.All, playersInTheRoom[index + 1]);
                }

                playersInTheRoom.RemoveAt(index);
            }
        }
        else
        {
            SomePlayerWon(PhotonNetwork.LocalPlayer);
        }
    }


    public void OnClick_Rematch()
    {
        isRematchSelected = true;
        photonView.RPC("ReceivedRematch", RpcTarget.AllBufferedViaServer, PhotonNetwork.LocalPlayer);
        PhotonNetwork.AutomaticallySyncScene = false;

        PhotonNetwork.LoadLevel(3);
    }


    void ReceivedRematch(Player player)
    {
        if (player != PhotonNetwork.LocalPlayer)
        {
        	if (!isRematchSelected){}
                //rematchText.text = "Player " + player.NickName + " Has Requested Rematch";
            // else //We can add Player has Joined the Match!
            //     rematchText.text = "Player " + player.NickName + " Has Joined Rematch";
        }
    }
}