﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Photon.Pun;
using System.IO;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameSetup : MonoBehaviour
{
    public PhotonView PV;
    public static GameSetup GS;
    public Transform spawnPostion;
    public Text CountdownText;
    public int StartingTime;
    public bool IsGameStarted;
    public bool gameOver;
    public int readyPlayersCount;
    public List<GameObject> Players;
    public int currentTurn;
    public int round;
    public int playerTurnComplete;
    private void OnEnable()
    {
        if (GameSetup.GS == null) {
			GameSetup.GS = this;
		}
        else
        {
		    if(GameSetup.GS != null){
			    Destroy (GameSetup.GS.gameObject);
				GameSetup.GS = this;
			}
		}
    }
    void Start()
    {
        PV = GetComponent<PhotonView>();
        StartCoroutine (StartDelay());
        round = 1;
    }
    void Update()
    {
        if(playerTurnComplete == Players.Count && Players.Count != 0){
            round++;
            playerTurnComplete = 0;
        }
    }
    public void DisconnectPlayer()
    {
        Destroy(PhotonRoom.photonRoom.gameObject);
        StartCoroutine(DisconnectAndLoad());
    }
    IEnumerator DisconnectAndLoad()
    {
        PhotonNetwork.LeaveRoom();
        while (PhotonNetwork.InRoom)
        {
            yield return null;
        }
        PhotonNetwork.LoadLevel(MultiplayerSettings.mpSettings.menuScene);
    }
    IEnumerator StartDelay(){
		CountdownText.gameObject.SetActive (true);
		while (StartingTime > 0) {
			yield return new WaitForSeconds (1f);
			StartingTime--;
			CountdownText.text = StartingTime.ToString();
			if (StartingTime<=0){
				if (PhotonNetwork.IsMasterClient) {
				    //StartGame(StartingTime);
                    PV.RPC("StartGame", RpcTarget.All, StartingTime);
				}
			}
		}
	}
    [PunRPC]
    public void StartGame(int startingTime)
    {
		if (startingTime <= 0) {
			IsGameStarted = true;
			CountdownText.gameObject.SetActive (false);
		}
	}
    public void CheckPlayersReady()
    {
        //readyPlayersCount = 0;
		for (int i = 0; i < Players.Count; i++)
        {
			var np = Players[i].GetComponent<CharacterControl>();
			if (np.readyToPlay)
				readyPlayersCount++;
        }
		if (readyPlayersCount == PhotonRoom.photonRoom.playerInRoom){
            //CheckTurn();
            PV.RPC("CheckTurn", RpcTarget.MasterClient);
        }
    }
    [PunRPC]
    public void CheckTurn()
    {
		if(!gameOver && PV.IsMine){
            print("Checking Turn");
			for (int j = 0; j < Players.Count; j++)
			{
				var player = Players[j].GetComponent<CharacterControl>();
                if (j == currentTurn&&player.pv.IsMine)
                {
                    player.gameObject.SetActive(true);
                    print(player.name + "'s turn");
                    PV.RPC("ActiveTurn", RpcTarget.All, player.gameObject.GetPhotonView().ViewID);

                }
                else
                {
                    player.gameObject.SetActive(false);
                    print("You are spectating");
                    PV.RPC("DeactiveTurn", RpcTarget.All, player.gameObject.GetPhotonView().ViewID);
                }
				//DeckCompleteCheck(Players[j]);
				//if (player.isBot && j == currentTurn)
				//{
                    
				//}
			}
		}
	}
    public void ChangeTurn(){
        Debug.Log("Changes Turn");
		if (currentTurn < Players.Count - 1)
		{
			currentTurn += 1;
            PV.RPC("TurnUpdate", RpcTarget.OthersBuffered, currentTurn);
		}
        else
        {
        	currentTurn = 0;
            PV.RPC("TurnUpdate", RpcTarget.OthersBuffered, currentTurn);
        }
		print(currentTurn);
		//CheckTurn();
        PV.RPC("CheckTurn", RpcTarget.MasterClient);
    }

    public void RoundUpdateCheck(){
        for (int j = 0; j < Players.Count; j++)
		{
            var playerRules = Players[j].GetComponent<Rules>();
            if(playerRules.TurnCompleted == round){
                playerTurnComplete++;
            }
        }
    }
    public void DisconnectFromRoom(){
		StartCoroutine(DisConnectandLoad());
	}
	IEnumerator DisConnectandLoad(){
		PhotonNetwork.LeaveRoom ();
		while (PhotonNetwork.InRoom) 
			yield return null;
		SceneManager.LoadScene (MultiplayerSettings.mpSettings.menuScene);
		//Time.timeScale = 1;
	}
    public void FinishGame(){
        
    }

    /*public void AddPlayerToNetwork(GameObject myPlayer){
        PV.RPC("RPC_AddPlayerToNetwork", RpcTarget.All, myPlayer.gameObject.GetPhotonView().ViewID);
    }*/
    [PunRPC]
    void ActiveTurn(int playerViewID){
        GameObject myplayer  = PhotonView.Find(playerViewID).gameObject;
        myplayer.gameObject.SetActive(true);
    }
    [PunRPC]
    void DeactiveTurn(int playerViewID){
        GameObject myplayer  = PhotonView.Find(playerViewID).gameObject;
        myplayer.gameObject.SetActive(false);
    }
    [PunRPC]
    void TurnUpdate(int thisCurrentTurn){
        currentTurn = thisCurrentTurn;
    }
}
