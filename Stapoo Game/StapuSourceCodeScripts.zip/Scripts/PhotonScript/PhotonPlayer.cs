﻿using Photon.Pun;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using UnityEngine.UI;

public class PhotonPlayer : MonoBehaviour
{
    public PhotonView PV;
    public GameObject myPlayer;
    public int MyTeam;

    // Start is called before the first frame update
    void Start()
    {
        PV = GetComponent<PhotonView>();
//        if (PV.IsMine)
//        {
//            PV.RPC("RPC_GettingTeam", RpcTarget.AllBuffered);
//        }

    }

    void LateUpdate()
    {
        if (myPlayer==null && GameSetup.GS.IsGameStarted)
        {
            if (PV.IsMine)
            {
                myPlayer = PhotonNetwork.Instantiate(Path.Combine("PhotonPrefabs", "Player"),
                GameSetup.GS.spawnPostion.position, GameSetup.GS.spawnPostion.rotation, 0);
                PV.RPC("AddMyPlayer", RpcTarget.All, myPlayer.gameObject.GetPhotonView().ViewID);
            }
        }
    }
    [PunRPC]
    void AddMyPlayer(int PlayerView){
        GameObject player  = PhotonView.Find(PlayerView).gameObject;
        //player.name = PlayerPrefs.GetString("Name");
        player.name = PhotonRoom.photonRoom.userName;
        GameSetup.GS.Players.Add(player);
        player.GetComponent<CharacterControl>().readyToPlay = true;
        player.SetActive(false);
        print(player);
        PV.RPC("TurnCheck", RpcTarget.All);
    }
    [PunRPC]
    void TurnCheck(){
        GameSetup.GS.CheckPlayersReady();
    }
}
