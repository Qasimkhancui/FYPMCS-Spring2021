﻿using Photon.Pun;
using Photon.Realtime;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PhotonLobby : MonoBehaviourPunCallbacks
{
    public static PhotonLobby photonLobby;
    //RoomInfo[] room;

    public GameObject spButton;
    public GameObject mpButton;
    public GameObject cancelButton;
    public GameObject quitButton;
    public Text conntectionStatus;
    public GameObject PhotonRoomObj;
    public Text PlayerName;

    // Start is called before the first frame update
    private void Awake()
    {
        photonLobby = this;
    }
    void Start()
    {
        conntectionStatus.text = "Connecting...";
        PhotonNetwork.ConnectUsingSettings();
        PlayerName.text = PlayerPrefs.GetString("Name");
    }

    public override void OnConnectedToMaster()
    {
        conntectionStatus.text = "Connected";
        PhotonNetwork.AutomaticallySyncScene = true;
        spButton.SetActive(true);
        mpButton.SetActive(true);
        quitButton.SetActive(true);
    }
    public void OnPlayButtonClicked()
    {
        spButton.SetActive(false);
        mpButton.SetActive(false);
        quitButton.SetActive(false);
        cancelButton.SetActive(true);
        PhotonNetwork.JoinRandomRoom();
    }

    public void OnCancelButtonClicked()
    {
        conntectionStatus.text = "Leaving Room";
        cancelButton.SetActive(false);
        PhotonNetwork.LeaveRoom();
        PhotonRoom.photonRoom.RoomPlayerData.text = "";
        PhotonRoom.photonRoom.readyToCount = false;
        spButton.SetActive(true);
        mpButton.SetActive(true);
        quitButton.SetActive(true);
        conntectionStatus.text = "Left Room Successfully";
    }

    public override void OnJoinRandomFailed(short returnCode, string message)
    {
        conntectionStatus.text = "No Room Available\nCreating New Room";
        CreateRoom();
    }

    void CreateRoom()
    {
        int randomRoomName = Random.Range(0, 10000);
        RoomOptions roomOps = new RoomOptions()
        {
            IsVisible = true,
            IsOpen = true,
            MaxPlayers = (byte)MultiplayerSettings.mpSettings.maxPlayer,
            PublishUserId = true
        };
        PhotonNetwork.CreateRoom("Room " + randomRoomName, roomOps);
        //PhotonRoomObj.GetComponent<PhotonRoom>().enabled = true;
    }

    public override void OnCreateRoomFailed(short returnCode, string message)
    {
        conntectionStatus.text = "Room Name Duplicate found";
        CreateRoom();
    }

    public void Quit()
    {
    	Application.Quit();
    }
}
