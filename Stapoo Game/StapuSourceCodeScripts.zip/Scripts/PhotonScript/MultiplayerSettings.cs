﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MultiplayerSettings : MonoBehaviour
{
    public static MultiplayerSettings mpSettings;

    public bool delayStart;
    public int maxPlayer;

    public int menuScene;
    public int gameScene;
    // Start is called before the first frame update
    private void Awake()
    {
        if (MultiplayerSettings.mpSettings == null)
        {
            MultiplayerSettings.mpSettings = this;
        }
        else
        {
            if (MultiplayerSettings.mpSettings != this)
            {
                Destroy(this.gameObject);
            }
        }
        DontDestroyOnLoad(this.gameObject);
    }

    public void sp(){
        maxPlayer = 1;
    }
    public void mp(){
        maxPlayer = 2;
    }
}
