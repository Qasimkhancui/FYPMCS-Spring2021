﻿using Photon.Pun;
using Photon.Realtime;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System.IO;

public class PhotonRoom :MonoBehaviourPunCallbacks, IInRoomCallbacks
{
    public static PhotonRoom photonRoom;
    private PhotonView PV;

    public bool isGameLoaded;
    public int currentScene;

    Player[] photonPlayer;
    public int playerInRoom;
    public int myNumberInRoom;
    public int playerInGame;

    public bool readyToCount;
    private bool readyToStart;
    public float startingTime;
    private float lessthanMaxPlayer;
    private float atMaxPlayer;
    private float timeToStart;
    public Text RoomPlayerData;
    public int TeamLimit;
    public string userName;
    

    void Awake()
    {
        if (PhotonRoom.photonRoom == null)
        {
            PhotonRoom.photonRoom = this;
        }
        else
        {
            if (PhotonRoom.photonRoom != this)
            {
                Destroy(PhotonRoom.photonRoom.gameObject);
                PhotonRoom.photonRoom = this;
            }
        }
        DontDestroyOnLoad(this.gameObject);
    }

    public override void OnEnable()
    {
        base.OnEnable();
        PhotonNetwork.AddCallbackTarget(this);
        SceneManager.sceneLoaded += OnSceneFinishedLoading;
    }
    public override void OnDisable()
    {
        base.OnDisable();
        PhotonNetwork.RemoveCallbackTarget(this);
        SceneManager.sceneLoaded -= OnSceneFinishedLoading;
    }

    // Start is called before the first frame update
    void Start()
    {
        PV = GetComponent<PhotonView>();
        readyToCount = false;
        readyToStart = false;
        lessthanMaxPlayer = startingTime;
        atMaxPlayer = 6;
        timeToStart = startingTime;
    }

    // Update is called once per frame
    void Update()
    {
        if (MultiplayerSettings.mpSettings.delayStart)
        {
            if (playerInRoom == 0)
            {
                RestartTimer();
            }
            if (!isGameLoaded)
            {
                if (readyToStart)
                {
                    atMaxPlayer -= Time.deltaTime;
                    lessthanMaxPlayer = atMaxPlayer;
                    timeToStart = atMaxPlayer;
                }
                else if (readyToCount)
                {
                    lessthanMaxPlayer -= Time.deltaTime;
                    timeToStart = lessthanMaxPlayer;
                    Debug.Log("Starting in " + timeToStart.ToString("f0"));
                }
                if (timeToStart <= 0)
                {
                    userName = PhotonLobby.photonLobby.PlayerName.text;
                    StartGame();
                }
                if (!readyToCount)
                {
                    timeToStart = startingTime;
                }
            }
        }
    }

    public override void OnJoinedRoom()
    {

        base.OnJoinedRoom();
        PhotonLobby.photonLobby.conntectionStatus.text = "Joined Room Successfully";
        photonPlayer = PhotonNetwork.PlayerList;
        playerInRoom = photonPlayer.Length;
        myNumberInRoom = playerInRoom;
        PhotonNetwork.NickName = myNumberInRoom.ToString();
        if (MultiplayerSettings.mpSettings.delayStart)
        {
            RoomPlayerData.text = "Connected Players (" + playerInRoom + "/" + MultiplayerSettings.mpSettings.maxPlayer + ")";
//            if (playerInRoom >= MultiplayerSettings.mpSettings.maxPlayer)
//            {
//                readyToCount = true;
//            }
            if (playerInRoom == MultiplayerSettings.mpSettings.maxPlayer)
            {
                readyToStart = true;
                if (!PhotonNetwork.IsMasterClient)
                {
                    return;
                }
                PhotonNetwork.CurrentRoom.IsOpen = false;
            }
        }
        else
        {
            StartGame();
        }
    }

    public override void OnPlayerEnteredRoom(Player newPlayer)
    {
        base.OnPlayerEnteredRoom(newPlayer);
        RoomPlayerData.text = "New Player Joined";
        photonPlayer = PhotonNetwork.PlayerList;
        playerInRoom++;
        if (MultiplayerSettings.mpSettings.delayStart)
        {
            RoomPlayerData.text = "Connected Players (" + playerInRoom + "/" + MultiplayerSettings.mpSettings.maxPlayer + ")";
            if (playerInRoom >= 1)
            {
                readyToCount = true;
            }
            if (playerInRoom == MultiplayerSettings.mpSettings.maxPlayer)
            {
                readyToStart = true;
                if (!PhotonNetwork.IsMasterClient)
                {
                    return;
                }
                PhotonNetwork.CurrentRoom.IsOpen = false;
            }
        }
    }

    void StartGame()
    {
        isGameLoaded = true;
        if (!PhotonNetwork.IsMasterClient)
        {
            return;
        }
        if (MultiplayerSettings.mpSettings.delayStart)
        {
            PhotonNetwork.CurrentRoom.IsOpen = false;
        }
        PhotonNetwork.LoadLevel(MultiplayerSettings.mpSettings.gameScene);
    }

    void RestartTimer()
    {
        lessthanMaxPlayer = startingTime;
        timeToStart = startingTime;
        atMaxPlayer = 6;
        readyToCount = false;
        readyToStart = false;
    }

    void OnSceneFinishedLoading(Scene scene, LoadSceneMode mode)
    {
        currentScene = scene.buildIndex;
        if (currentScene == MultiplayerSettings.mpSettings.gameScene)
        {
            isGameLoaded = true;
            if (MultiplayerSettings.mpSettings.delayStart)
            {
                PV.RPC("RPC_LoadedGameScene", RpcTarget.MasterClient);
            }
            else
            {
                RPC_CreatePlayer();
                playerInGame++;
                Debug.Log(playerInGame);
            }
        }
    }

    [PunRPC]
    private void RPC_LoadedGameScene()
    {
        playerInGame++;
        Debug.Log(playerInGame);
        if (playerInGame == PhotonNetwork.PlayerList.Length)
        {
            PV.RPC("RPC_CreatePlayer", RpcTarget.AllBuffered);
        }
    }

    [PunRPC]
    private void RPC_CreatePlayer()
    {
        PhotonNetwork.Instantiate(Path.Combine("PhotonPrefabs", "PhotonNetworkPlayer"), transform.position, Quaternion.identity, 0);
    }

    public override void OnPlayerLeftRoom(Player otherPlayer)
    {
        base.OnPlayerLeftRoom(otherPlayer);
        Debug.Log(otherPlayer.NickName + " has left the game");
        playerInGame--;
    }
}