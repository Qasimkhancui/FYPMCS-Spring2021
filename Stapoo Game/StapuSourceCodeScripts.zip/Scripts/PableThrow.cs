﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Photon.Pun;

public class PableThrow : MonoBehaviour
{
	public float power = 10f;
	public float maxDrag = 5f;
	Rigidbody rb;
	public LineRenderer lr;
	public GameObject player;
	CharacterControl CCScript;

	Vector3 dragStartPos;
	//Touch touch;
	Vector3 mousePos;
	
	public PhotonView pv;
	public Camera playerCam;
	

	void Start(){
		if(pv.IsMine){
			pv = this.gameObject.GetComponent<PhotonView>();
			CCScript = player.GetComponent<CharacterControl>();
		}
		else{
			playerCam.enabled = false;
			return;
		}
	}
	private void Update(){
		if(!pv.IsMine){
			return;
		}
		mousePos = Input.mousePosition;
   		mousePos.z = 3;
		//if(Input.touchCount > 0){
			//touch = Input.GetTouch(0);
			//Debug.Log(Camera.main.ScreenToWorldPoint(mousePos));
			if(Input.GetMouseButtonDown(0)){
				DragStart();
			}
			if(Input.GetMouseButton(0)){
				Dragging();
			}
			if(Input.GetMouseButtonUp(0)){
				DragRelease();
			}
		//}
	}
	
	void DragStart(){
		pv.RPC("RPC_DragStart",RpcTarget.All);
	}
	[PunRPC]
	void RPC_DragStart(){
		dragStartPos = playerCam.ScreenToWorldPoint(mousePos);
		//dragStartPos.z = 0;
		dragStartPos.y = 0.2f;
		lr.positionCount = 1;
		lr.SetPosition(0, dragStartPos);
	}
	void Dragging(){
		pv.RPC("RPC_Dragging",RpcTarget.All);
	}
	[PunRPC]
	void RPC_Dragging(){
		Vector3 draggingPos = playerCam.ScreenToWorldPoint(mousePos);
		draggingPos.y = 0.2f;
		//draggingPos.x = 0f;
		lr.positionCount = 2;
		lr.SetPosition(1, draggingPos);
	}
	void DragRelease(){
		pv.RPC("RPC_DragRelease",RpcTarget.All);
	}
	[PunRPC]
	void RPC_DragRelease(){
		lr.positionCount = 0;
		Vector3 draggingReleased = playerCam.ScreenToWorldPoint(mousePos);
		CCScript.enabled = true;
		gameObject.transform.parent = null;
		rb = gameObject.AddComponent<Rigidbody>();
		rb.mass = 5;
		
		Vector3 force = dragStartPos - draggingReleased;
		//Debug.Log("Force "+ force.z);
		Vector3 clampedForce = Vector3.ClampMagnitude(force, maxDrag) * power;
		//Debug.Log("ClampedForce "+ clampedForce.z);
		rb.AddForce(clampedForce, ForceMode.Impulse);
	}
}
