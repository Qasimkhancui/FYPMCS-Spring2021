﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Playables;

public class Authentication : MonoBehaviour {
	public InputField NameBar;
	public GameObject AuthenticationScreen;
	public GameObject LoginScreen;
	public GameObject PhotonLobby;
	// Use this for initialization
	void Start () {
		//PlayerPrefs.DeleteAll();
		if (PlayerPrefs.HasKey("Name")&&PlayerPrefs.GetString("Name")!=""){
			Debug.Log ("Name of PLayer is="+PlayerPrefs.GetString("Name"));
			//MainMenu.mainMenu.Camera.GetComponent<CameraViewGamepLay>().enabled=true;
			PhotonLobby.GetComponent<PhotonLobby>().enabled=true;
			gameObject.SetActive(false);
			}
		else{
			AuthenticationScreen.SetActive (false);
			LoginScreen.SetActive (true);
			Debug.Log("Failed to authenticate");
			}
		}
	public void Login(){
		if (NameBar.text.Length > 3) {
			PlayerPrefs.SetString ("Name", NameBar.text.ToString ());
			PlayerPrefs.Save ();
			//MainMenu.mainMenu.Camera.GetComponent<CameraViewGamepLay> ().enabled = true;
			PhotonLobby.GetComponent<PhotonLobby>().enabled=true;
			gameObject.SetActive (false);
			//Timeline.GetComponent<PlayableDirector>().enabled = true;
		} else {
			Debug.Log("InCorrect Username");
		}
	}
}
