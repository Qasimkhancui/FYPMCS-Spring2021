﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Photon.Pun;

public class Rules : MonoBehaviour
{
	public PhotonView PV;
	public int presentBox;
	public int nextBox;
	public int TurnCompleted;
	public GameObject pable;
	public GameObject hand;
	bool forward;
	bool backward;
	public Animator anim;
	Rigidbody rb;
	public Vector3 pablePos;
	public int RoundScore;
	public int TotalScore;
	public bool isTriggered;
	
	public GameObject panelMenu;
    // Start is called before the first frame update
    void Start()
    {
    	PV = gameObject.GetComponent<PhotonView>();
		forward = false;
    	backward = false;
    }

    // Update is called once per frame
    void Update()
    {
    	if(presentBox == GameSetup.GS.round && forward == true && backward == false){
    		if(presentBox == GameSetup.GS.round){
    			presentBox++;
    			nextBox++;
    		}
    	}
    	if(presentBox+1 == GameSetup.GS.round && forward == false && backward == true){
    		rb = pable.GetComponent<Rigidbody>();
        	Destroy(rb);
       		//pable.GetComponent<Collider>().enabled = false;
    		pable.transform.parent = hand.transform;
    		pable.gameObject.transform.localPosition = pablePos;
    	}
    }
    IEnumerator OnTriggerEnter(Collider col){

    	if(col.tag == presentBox.ToString() && forward == true && col.tag != pable.GetComponent<PableRules>().pableInBox.ToString()){
    		print(presentBox);
    		presentBox++;
    		nextBox++;
			RoundScore++;
    	}
    	else if(col.tag == presentBox.ToString() && backward == true){
    		print(presentBox);
    		presentBox--;
    		nextBox--;
			RoundScore++;
    	}
    	else if((col.tag != presentBox.ToString() && col.tag != "start" && col.tag != "end")
    	        || (col.tag == pable.GetComponent<PableRules>().pableInBox.ToString() && forward == true && backward == false)){
    		Debug.Log(col.tag);
    		Debug.Log(pable.GetComponent<PableRules>().pableInBox.ToString());
    		Debug.Log(presentBox.ToString());
    		yield return new WaitForSeconds(0.3f);
    		//Time.timeScale = 0;
    		//panelMenu.SetActive(true);
    		//print("Please Restart");
			//PV.RPC("RoundUpdate", RpcTarget.MasterClient);
			//PV.RPC("TurnCheck", RpcTarget.MasterClient);
			//GameSetup.GS.RoundUpdateCheck();
			//GameSetup.GS.ChangeTurn();
    	}
		
		if(col.tag == "start" && backward == true ){
    		TurnCompleted++;
    		print("Round Complete");
			//PV.RPC("RoundUpdate", RpcTarget.MasterClient);
			//PV.RPC("TurnCheck", RpcTarget.MasterClient);
			GameSetup.GS.RoundUpdateCheck();
			GameSetup.GS.ChangeTurn();
			RoundScore = 0;
			TotalScore += RoundScore;
    	}
    	if(col.tag == "end"){
    		forward = false;
    		backward = true;
    		presentBox--;
    		nextBox -= 2;
    		transform.eulerAngles = new Vector3(0,180,0);
    	}
    	if(col.tag == "start"){
    		presentBox = 1;
        	nextBox = 2;
			forward = true;
        	backward = false;
        	transform.eulerAngles = new Vector3(0,0,0);
        	if(pable.transform.parent == hand.transform){
        		gameObject.GetComponent<CharacterControl>().enabled = false;
        		pable.GetComponent<PableThrow>().enabled = true;
        	}
    	}
    }
    
    void OnTriggerExit(Collider col){
    }
	
	[PunRPC]
    void TurnCheck(){
        GameSetup.GS.ChangeTurn();
    }
	[PunRPC]
    void RoundUpdate(){
        GameSetup.GS.RoundUpdateCheck();
    }

}